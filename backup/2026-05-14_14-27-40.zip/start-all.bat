@echo off
chcp 65001 >nul
echo ========================================
echo   攀升工厂设备管理系统 - 服务启动
echo ========================================
echo.

:: 停止现有服务
echo [1/3] 停止现有服务...
npx pm2 delete all >nul 2>&1

:: 启动后端
echo [2/3] 启动后端服务...
cd /d C:\Users\Admin\WorkBuddy\2026-05-10-task-1\backend
start /b cmd /c "npx pm2 start server.js --name device-backend --cwd C:\Users\Admin\WorkBuddy\2026-05-10-task-1\backend"

:: 等待后端启动
timeout /t 3 /nobreak >nul

:: 启动前端
echo [3/3] 启动前端服务...
cd /d C:\Users\Admin\WorkBuddy\2026-05-10-task-1\frontend
start /b cmd /c "npx vite --host --port 5173"

:: 等待服务启动
timeout /t 5 /nobreak >nul

:: 显示状态
echo.
echo ========================================
echo   服务状态
echo ========================================
npx pm2 status

echo.
echo ========================================
echo   启动完成！
echo   前端访问: http://localhost:5173
echo   后端API:  http://localhost:3001
echo ========================================
pause
