module.exports = (db, upload, excelDateToString) => {
  const express = require('express');
  const xlsx = require('xlsx');
  const path = require('path');
  const router = express.Router();
  const { requireAuth, requireAdmin } = require('../middleware/auth');

  // 自动生成备件编号
  function genPartNo() {
    const last = db.prepare(
      'SELECT part_no FROM parts ORDER BY id DESC LIMIT 1'
    ).get();
    let n = 1;
    if (last && last.part_no) {
      // 支持 PART-0001 或纯数字格式
      const match = last.part_no.match(/(\d+)$/);
      if (match) n = parseInt(match[1]) + 1;
    }
    return 'PART-' + String(n).padStart(4, '0');
  }

  // 获取下一个备件编号
  router.get('/next-no', requireAuth, (req, res) => {
    res.json({ next_no: genPartNo() });
  });

  // ===== 零部件台账 CRUD =====
  router.get('/', requireAuth, (req, res) => {
    const { keyword } = req.query;
    let rows;
    const orderBy = `ORDER BY category, part_no, id`;
    if (keyword && keyword.trim()) {
      const k = `%${keyword.trim()}%`;
      rows = db.prepare(`
        SELECT * FROM parts
        WHERE part_no LIKE ? OR name LIKE ? OR spec LIKE ?
           OR brand LIKE ? OR storage_location LIKE ? OR applicable_devices LIKE ?
        ${orderBy}
      `).all(k, k, k, k, k, k);
    } else {
      rows = db.prepare(`SELECT * FROM parts ${orderBy}`).all();
    }
    res.json(rows);
  });

  router.post('/', requireAdmin, (req, res) => {
    const d = req.body;
    try {
      const partNo = d.part_no || genPartNo();
      const r = db.prepare(`
        INSERT INTO parts (part_no, name, spec, brand, applicable_devices,
          storage_location, stock, safety_stock, unit, unit_price, supplier,
          purchase_cycle_days, remarks, category)
        VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        partNo, d.name, d.spec, d.brand ?? null, d.applicable_devices ?? null,
        d.storage_location, d.stock, d.safety_stock, d.unit ?? '个',
        d.unit_price ?? null, d.supplier ?? null, d.purchase_cycle_days ?? null,
        d.remarks ?? '', d.category ?? ''
      );
      // 写初始入库记录
      db.prepare(`
        INSERT INTO inventory_logs (log_no, log_date, part_id, operation_type,
          quantity, handler, remarks)
        VALUES (?,date('now','localtime'),?, '入库',?, '系统初始化', ?)
      `).run('INIT-' + Date.now(), r.lastInsertRowid, d.stock, d.remarks ?? '');
      res.json({ id: r.lastInsertRowid, part_no: partNo });
    } catch (e) {
      console.error('POST /parts error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  router.put('/:id', requireAdmin, (req, res) => {
    const d = req.body;
    try {
      db.prepare(`
        UPDATE parts SET part_no=?, name=?, spec=?, brand=?,
          applicable_devices=?, storage_location=?, stock=?, safety_stock=?,
          unit=?, unit_price=?, supplier=?, purchase_cycle_days=?, category=?
        WHERE id=?
      `).run(
        d.part_no ?? null, d.name, d.spec, d.brand ?? null,
        d.applicable_devices ?? null, d.storage_location,
        d.stock != null ? Number(d.stock) : 0,
        d.safety_stock != null ? Number(d.safety_stock) : 0,
        d.unit ?? '个', d.unit_price ?? null, d.supplier ?? null,
        d.purchase_cycle_days ?? null, d.category ?? '',
        req.params.id
      );
      res.json({ success: true });
    } catch (e) {
      console.error('PUT /parts/:id error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // 快速修改库存（行内编辑专用）
  router.patch('/:id/stock', requireAdmin, (req, res) => {
    const { stock } = req.body;
    try {
      db.prepare('UPDATE parts SET stock=? WHERE id=?').run(Number(stock), req.params.id);
      res.json({ success: true });
    } catch (e) {
      console.error('PATCH /parts/:id/stock error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  router.delete('/:id', requireAdmin, (req, res) => {
    try {
      // 先删关联的出入库日志（外键约束），再删备件
      db.prepare('DELETE FROM inventory_logs WHERE part_id=?').run(req.params.id);
      db.prepare('DELETE FROM parts WHERE id=?').run(req.params.id);
      res.json({ success: true });
    } catch (e) {
      console.error('DELETE /parts/:id error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // ===== 领用接口 =====
  router.post('/usage', requireAuth, (req, res) => {
    const d = req.body;
    const partId = Number(d.part_id);
    const qty = Number(d.quantity) || 1;
    try {
      // 查当前库存
      const part = db.prepare('SELECT * FROM parts WHERE id=?').get(partId);
      if (!part) return res.status(404).json({ error: '备件不存在' });
      if (part.stock < qty) {
        return res.status(400).json({ error: `库存不足，当前库存为 ${part.stock}` });
      }
      // 事务：扣库存 + 写记录
      db.prepare('UPDATE parts SET stock = stock - ? WHERE id=?').run(qty, partId);
      db.prepare(`
        INSERT INTO inventory_logs
          (log_no, log_date, part_id, operation_type, quantity, handler, remarks, line, purpose)
        VALUES (?, ?, ?, '领用', ?, ?, ?, ?, ?)
      `).run(
        'USE-' + Date.now(),
        d.log_date || new Date().toISOString().slice(0, 10),
        partId, qty,
        d.handler ?? '',
        d.remarks ?? '',
        d.line ?? '',
        d.purpose ?? ''
      );
      const updated = db.prepare('SELECT stock FROM parts WHERE id=?').get(partId);
      res.json({ success: true, stock: updated.stock });
    } catch (e) {
      console.error('POST /parts/usage error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // ===== 入库接口 =====
  router.post('/stockin', requireAdmin, (req, res) => {
    const d = req.body;
    const partId = Number(d.part_id);
    const qty = Number(d.quantity);
    if (!qty || qty <= 0) return res.status(400).json({ error: '入库数量必须为正整数' });
    try {
      const part = db.prepare('SELECT * FROM parts WHERE id=?').get(partId);
      if (!part) return res.status(404).json({ error: '备件不存在' });
      db.prepare('UPDATE parts SET stock = stock + ? WHERE id=?').run(qty, partId);
      db.prepare(`
        INSERT INTO inventory_logs
          (log_no, log_date, part_id, operation_type, quantity, handler, remarks)
        VALUES (?, ?, ?, '入库', ?, ?, ?)
      `).run(
        'IN-' + Date.now(),
        d.log_date || new Date().toISOString().slice(0, 10),
        partId, qty,
        d.handler ?? '',
        d.remarks ?? ''
      );
      const updated = db.prepare('SELECT stock FROM parts WHERE id=?').get(partId);
      res.json({ success: true, stock: updated.stock });
    } catch (e) {
      console.error('POST /parts/stockin error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // ===== 领用记录查询 =====
  router.get('/usage', requireAuth, (req, res) => {
    const { keyword, start_date, end_date } = req.query;
    let sql = `
      SELECT l.*, p.name as part_name, p.part_no as part_no_ref, p.unit as part_unit
      FROM inventory_logs l
      LEFT JOIN parts p ON p.id = l.part_id
      WHERE l.operation_type = '领用'
    `;
    const params = [];
    if (keyword && keyword.trim()) {
      sql += ` AND (p.name LIKE ? OR p.part_no LIKE ? OR l.handler LIKE ?)`;
      const k = `%${keyword.trim()}%`;
      params.push(k, k, k);
    }
    if (start_date) { sql += ` AND l.log_date >= ?`; params.push(start_date); }
    if (end_date) { sql += ` AND l.log_date <= ?`; params.push(end_date); }
    sql += ' ORDER BY l.id DESC';
    try {
      const rows = db.prepare(sql).all(...params);
      res.json(rows);
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  // ===== 入库记录查询 =====
  router.get('/stockin', requireAuth, (req, res) => {
    const { keyword, start_date, end_date } = req.query;
    let sql = `
      SELECT l.*, p.name as part_name, p.part_no as part_no_ref, p.unit as part_unit
      FROM inventory_logs l
      LEFT JOIN parts p ON p.id = l.part_id
      WHERE l.operation_type = '入库'
    `;
    const params = [];
    if (keyword && keyword.trim()) {
      sql += ` AND (p.name LIKE ? OR p.part_no LIKE ? OR l.handler LIKE ?)`;
      const k = `%${keyword.trim()}%`;
      params.push(k, k, k);
    }
    if (start_date) { sql += ` AND l.log_date >= ?`; params.push(start_date); }
    if (end_date) { sql += ` AND l.log_date <= ?`; params.push(end_date); }
    sql += ' ORDER BY l.id DESC';
    try {
      const rows = db.prepare(sql).all(...params);
      res.json(rows);
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  // ===== 出入库记录（旧接口兼容） =====
  router.get('/logs', requireAuth, (req, res) => {
    const rows = db.prepare(`
      SELECT l.*, p.name as part_name
      FROM inventory_logs l
      LEFT JOIN parts p ON p.id = l.part_id
      ORDER BY l.id DESC
    `).all();
    res.json(rows);
  });

  router.post('/logs', requireAdmin, (req, res) => {
    const d = req.body;
    const plano = d.log_no || ('IO-' + Date.now());
    if (d.operation_type === '出库') {
      db.prepare('UPDATE parts SET stock = stock - ? WHERE id = ?').run(d.quantity, d.part_id);
    } else if (d.operation_type === '入库') {
      db.prepare('UPDATE parts SET stock = stock + ? WHERE id = ?').run(d.quantity, d.part_id);
    } else if (d.operation_type === '盘点调整') {
      db.prepare('UPDATE parts SET stock = ? WHERE id = ?').run(d.quantity, d.part_id);
    } else if (d.operation_type === '报废') {
      db.prepare('UPDATE parts SET stock = stock - ? WHERE id = ?').run(d.quantity, d.part_id);
    }
    db.prepare(`
      INSERT INTO inventory_logs (log_no, log_date, part_id, operation_type,
        quantity, related_work_order, handler, remarks)
      VALUES (?,?, ?, ?, ?, ?, ?, ?)
    `).run(plano, d.log_date, d.part_id, d.operation_type,
      d.quantity, d.related_work_order || '', d.handler, d.remarks || '');
    res.json({ success: true });
  });

  // ===== Excel批量导入零部件台账 =====
  router.post('/import', requireAdmin, upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: '未收到文件' });
    try {
      const workbook = xlsx.readFile(req.file.path);
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const data = xlsx.utils.sheet_to_json(sheet, { header: 1, defval: '' });
      let imported = 0, skipped = 0;
      for (let i = 4; i < data.length; i++) {
        const row = data[i];
        if (!row || !row[1] || !row[2] || !row[5] || !row[6] || !row[7]) {
          if (row && row[1]) skipped++;
          continue;
        }
        try {
          db.prepare(`
            INSERT OR IGNORE INTO parts
              (part_no, name, spec, brand, applicable_devices,
               storage_location, stock, safety_stock, unit, unit_price, supplier,
               purchase_cycle_days, remarks)
            VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `).run(
            row[0] ? String(row[0]) : null, String(row[1]), String(row[2]),
            String(row[3] || ''), String(row[4] || ''), String(row[5]),
            Number(row[6]) || 0, Number(row[7]) || 0,
            String(row[8] || '个'), row[9] ? Number(row[9]) : null,
            String(row[10] || ''), row[11] ? Number(row[11]) : null,
            String(row[12] || '')
          );
          imported++;
        } catch (e) { skipped++; }
      }
      res.json({ success: true, imported, skipped });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  // ===== 低库存预警列表 =====
  router.get('/low-stock', requireAuth, (req, res) => {
    const rows = db.prepare(`
      SELECT * FROM parts WHERE stock < safety_stock ORDER BY stock ASC
    `).all();
    res.json(rows);
  });

  return router;
};
