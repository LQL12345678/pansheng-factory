module.exports = (db, excelDateToString) => {
  const express = require('express');
  const router = express.Router();
  const { requireAuth, requireAdmin, requireRepairStaff } = require('../middleware/auth');

  // 生成工单编号
  function genWO() {
    const d = new Date();
    const ds = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0');
    const prefix = 'WO-' + ds + '-';
    const last = db.prepare(
      'SELECT work_order_no FROM repairs WHERE work_order_no LIKE ? ORDER BY id DESC LIMIT 1'
    ).get(prefix + '%');
    let n = 1;
    if (last && last.work_order_no) {
      const parts = last.work_order_no.split('-');
      n = parseInt(parts[parts.length - 1]) + 1;
    }
    return prefix + String(n).padStart(3, '0');
  }

  // 获取下一个工单号
  router.get('/next-no', requireAuth, (req, res) => {
    res.json({ next_no: genWO() });
  });

  // 查询所有工单（支持筛选）
  router.get('/', requireAuth, (req, res) => {
    const { status, search, work_order_type } = req.query;
    let sql = `
      SELECT r.*, d.device_no, d.name as device_name, d.location as device_location
      FROM repairs r
      LEFT JOIN devices d ON d.id = r.device_id
      WHERE 1=1
    `;
    const params = [];
    if (status && status !== '全部') {
      sql += ` AND r.status = ?`;
      params.push(status);
    }
    if (work_order_type && work_order_type !== '全部') {
      sql += ` AND COALESCE(r.work_order_type, '设备维修') = ?`;
      params.push(work_order_type);
    }
    if (search && search.trim()) {
      const k = `%${search.trim()}%`;
      sql += ` AND (r.work_order_no LIKE ? OR r.line LIKE ? OR r.area LIKE ? OR r.fault_desc LIKE ? OR r.reporter LIKE ? OR r.repairman LIKE ?)`;
      params.push(k, k, k, k, k, k);
    }
    sql += ` ORDER BY r.id DESC`;
    try {
      const rows = db.prepare(sql).all(...params);
      // 为每个工单加载更换零件（含备件编号）
      for (const row of rows) {
        row.parts = db.prepare(
          'SELECT rp.*, p.part_no FROM repair_parts rp LEFT JOIN parts p ON p.id = rp.part_id WHERE rp.repair_id=?'
        ).all(row.id);
      }
      res.json(rows);
    } catch (e) {
      console.error('GET /repairs error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // 新增工单（普通用户可以新建报修）
  router.post('/', requireAuth, (req, res) => {
    const d = req.body;
    try {
      const woNo = d.work_order_no || genWO();
      const duration = d.duration_minutes || null;
      const stopDuration = d.stop_duration_minutes || null;
      const deviceId = d.device_id ? Number(d.device_id) : null;
      const r = db.prepare(`
        INSERT INTO repairs (work_order_no, report_date, report_time, device_id,
          line, reporter, area, fault_desc, fault_type, fault_cause, solution, parts_used,
          repairman, accept_time, finish_time, duration_minutes, stop_duration_minutes, status, remarks, work_order_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        woNo, d.report_date || null, d.report_time || null, deviceId,
        d.line || null, d.reporter || null, d.area || null,
        d.fault_desc || null, d.fault_type || null, d.fault_cause || null, d.solution || null, d.parts_used || null,
        d.repairman || null, d.accept_time || null, d.finish_time || null, duration, stopDuration, d.status || '待处理', d.remarks || null,
        d.work_order_type || '设备维修'
      );
      // 更新设备状态（仅当有设备ID时）
      if (deviceId) {
        db.prepare("UPDATE devices SET status='维修中' WHERE id=?").run(deviceId);
      }
      res.json({ id: r.lastInsertRowid, work_order_no: woNo });
    } catch (e) {
      console.error('POST /repairs error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // 更新工单（管理员或维修人员才能修改工单）
  router.put('/:id', requireRepairStaff, (req, res) => {
    const d = req.body;
    try {
      db.prepare(`
        UPDATE repairs SET report_date=?, report_time=?, device_id=?,
          line=?, reporter=?, area=?,
          fault_desc=?, fault_type=?, fault_cause=?, solution=?, parts_used=?,
          repairman=?, accept_time=?, finish_time=?, duration_minutes=?,
          stop_duration_minutes=?, status=?, remarks=?, work_order_type=?
        WHERE id=?
      `).run(
        d.report_date, d.report_time, d.device_id,
        d.line || null, d.reporter || null, d.area || null,
        d.fault_desc, d.fault_type, d.fault_cause, d.solution, d.parts_used,
        d.repairman || null, d.accept_time || null, d.finish_time || null, d.duration_minutes,
        d.stop_duration_minutes || null, d.status, d.remarks, d.work_order_type || '设备维修', req.params.id
      );
      // 工单完成，恢复设备状态
      if (d.status === '已完成') {
        db.prepare("UPDATE devices SET status='正常' WHERE id=?").run(d.device_id);
      }
      res.json({ success: true });
    } catch (e) {
      console.error('PUT /repairs/:id error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // 删除工单（管理员才能删除）
  router.delete('/:id', requireAdmin, (req, res) => {
    try {
      db.prepare('DELETE FROM repairs WHERE id=?').run(req.params.id);
      res.json({ success: true });
    } catch (e) {
      console.error('DELETE /repairs/:id error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // Excel批量导入（管理员）
  router.post('/import', requireAdmin, (req, res) => {
    res.json({ message: '请使用前端批量新增功能，或直接通过API逐条提交' });
  });

  // 标记处理中（管理员或维修人员）
  router.post('/:id/start', requireRepairStaff, (req, res) => {
    try {
      const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
      db.prepare(`UPDATE repairs SET status='处理中', accept_time=? WHERE id=?`)
        .run(now, req.params.id);
      res.json({ success: true });
    } catch (e) {
      console.error('POST /repairs/:id/start error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // 完成工单（事务：管理员或维修人员）
  router.post('/:id/complete', requireRepairStaff, (req, res) => {
    const d = req.body;
    const repairId = Number(req.params.id);
    try {
      const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
      const duration = d.duration_minutes ? Number(d.duration_minutes) : null;
      const stopDuration = d.stop_duration_minutes ? Number(d.stop_duration_minutes) : null;
      const parts = d.parts && Array.isArray(d.parts) ? d.parts : [];

      // 开始事务
      db.exec('BEGIN');

      // 1. 更新工单
      db.prepare(`
        UPDATE repairs SET
          status='已完成',
          finish_time=?,
          solution=?,
          parts_used=?,
          repairman=?,
          duration_minutes=?,
          stop_duration_minutes=?
        WHERE id=?
      `).run(
        now,
        d.solution || null,
        d.parts_used || null,
        d.repairman || null,
        duration,
        stopDuration,
        repairId
      );

      // 2. 删除旧的更换零件记录（支持重新完成）
      db.prepare('DELETE FROM repair_parts WHERE repair_id=?').run(repairId);

      // 3. 保存更换零件 + 扣减库存 + 写领用记录
      for (const item of parts) {
        const partId = Number(item.part_id);
        const qty = Number(item.quantity) || 1;

        // 检查库存是否充足
        const part = db.prepare('SELECT * FROM parts WHERE id=?').get(partId);
        if (!part) {
          db.exec('ROLLBACK');
          return res.status(400).json({ error: `备件不存在（ID: ${partId}）` });
        }
        if (part.stock < qty) {
          db.exec('ROLLBACK');
          return res.status(400).json({ error: `备件「${part.name}」库存不足！当前库存：${part.stock}，需要：${qty}` });
        }

        // 保存更换零件记录
        db.prepare(`
          INSERT INTO repair_parts (repair_id, part_id, part_name, quantity)
          VALUES (?, ?, ?, ?)
        `).run(repairId, partId, part.name, qty);

        // 扣减库存
        db.prepare('UPDATE parts SET stock = stock - ? WHERE id=?').run(qty, partId);

        // 写领用记录
        db.prepare(`
          INSERT INTO inventory_logs
            (log_no, log_date, part_id, operation_type, quantity, handler, remarks, related_work_order)
          VALUES (?, date('now','localtime'), ?, '领用', ?, ?, ?, ?)
        `).run(
          'USE-' + Date.now() + '-' + partId,
          partId,
          qty,
          d.repairman || '',
          '工单完成领用: ' + (d.work_order_no || repairId),
          d.work_order_no || ''
        );
      }

      // 4. 恢复设备状态
      const repair = db.prepare('SELECT device_id, work_order_no FROM repairs WHERE id=?').get(repairId);
      if (repair && repair.device_id) {
        db.prepare("UPDATE devices SET status='正常' WHERE id=?").run(repair.device_id);
      }

      // 提交事务
      db.exec('COMMIT');
      res.json({ success: true });
    } catch (e) {
      try { db.exec('ROLLBACK'); } catch (_) {}
      console.error('POST /repairs/:id/complete error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // ===== 统计看板 API =====
  // 维修工单统计概览（支持 work_order_type 筛选）
  router.get('/stats/overview', requireAuth, (req, res) => {
    try {
      const { work_order_type } = req.query;
      const today = new Date().toISOString().slice(0, 10);
      const weekStart = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);

      // 构建类型筛选 SQL 和参数（NULL 视为设备维修）
      const typeSql = (work_order_type && work_order_type !== '全部') ? " AND COALESCE(work_order_type, '设备维修') = ?" : '';
      const typeParam = (work_order_type && work_order_type !== '全部') ? [work_order_type] : [];

      const todayNew = db.prepare(
        'SELECT COUNT(*) as count FROM repairs WHERE report_date = ?' + typeSql
      ).get(today, ...typeParam).count;

      const inProgress = db.prepare(
        "SELECT COUNT(*) as count FROM repairs WHERE status = '处理中'" + typeSql
      ).get(...typeParam).count;

      const weekCompleted = db.prepare(
        "SELECT COUNT(*) as count FROM repairs WHERE status = '已完成' AND finish_time >= ?" + typeSql
      ).get(weekStart, ...typeParam).count;

      const weekTotal = db.prepare(
        'SELECT COUNT(*) as count FROM repairs WHERE report_date >= ?' + typeSql
      ).get(weekStart, ...typeParam).count;

      const weekRate = weekTotal > 0 ? Math.round(weekCompleted / weekTotal * 100) : 0;

      // 平均修复时间（最近30天已完成工单）
      const avgMTTR = db.prepare(
        `SELECT AVG(duration_minutes) as avg FROM repairs
         WHERE status = '已完成' AND finish_time >= datetime('now', '-30 day')`
        + typeSql
      ).get(...typeParam).avg || 0;

      res.json({
        todayNew,
        inProgress,
        weekCompleted,
        weekRate,
        avgMTTR: Math.round(avgMTTR * 10) / 10
      });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  // 高频故障设备排行（最近90天）
  router.get('/stats/high-frequency', requireAuth, (req, res) => {
    try {
      const rows = db.prepare(`
        SELECT
          d.name as deviceName,
          d.device_no as deviceNo,
          d.location as location,
          COUNT(r.id) as faultCount,
          ROUND(AVG(r.duration_minutes), 1) as avgDuration
        FROM repairs r
        JOIN devices d ON d.id = r.device_id
        WHERE r.created_at >= datetime('now', '-90 day')
        GROUP BY r.device_id
        ORDER BY faultCount DESC
        LIMIT 10
      `).all();
      res.json(rows);
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  // 月度趋势（按工单类型分组，支持年份和线体筛选）
  router.get('/stats/monthly-trend', requireAuth, (req, res) => {
    try {
      const { year, line } = req.query;
      let where = 'WHERE 1=1';
      const params = [];

      if (year && year !== '全部') {
        where += " AND strftime('%Y', report_date) = ?";
        params.push(String(year));
      } else {
        // 默认最近12个月
        where += " AND report_date >= date('now', '-12 month')";
      }
      if (line && line !== '全部') {
        where += ' AND line = ?';
        params.push(String(line));
      }

      const rows = db.prepare(`
        SELECT
          strftime('%Y-%m', report_date) as month,
          COALESCE(work_order_type, '设备维修') as work_order_type,
          COUNT(*) as total,
          SUM(CASE WHEN status = '已完成' THEN 1 ELSE 0 END) as completed,
          ROUND(AVG(duration_minutes), 1) as avgDuration
        FROM repairs
        ${where}
        GROUP BY strftime('%Y-%m', report_date), COALESCE(work_order_type, '设备维修')
        ORDER BY month ASC, work_order_type
      `).all(...params);
      res.json(rows);
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  // 线体维度统计表格（支持年份筛选）
  router.get('/stats/by-line', requireAuth, (req, res) => {
    try {
      const { year, line } = req.query;
      let where = 'WHERE 1=1';
      const params = [];

      if (year && year !== '全部') {
        where += " AND strftime('%Y', report_date) = ?";
        params.push(String(year));
      }
      if (line && line !== '全部') {
        where += ' AND line = ?';
        params.push(String(line));
      }

      const rows = db.prepare(`
        SELECT
          COALESCE(work_order_type, '设备维修') as work_order_type,
          line,
          COUNT(*) as total,
          SUM(CASE WHEN status = '已完成' THEN 1 ELSE 0 END) as completed,
          ROUND(SUM(CASE WHEN status = '已完成' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) as completionRate
        FROM repairs
        ${where}
        GROUP BY COALESCE(work_order_type, '设备维修'), line
        ORDER BY
          CASE COALESCE(work_order_type, '设备维修')
            WHEN '设备维修' THEN 1 WHEN '工具维修' THEN 2
            ELSE 3
          END,
          CASE line
            WHEN '1线' THEN 1 WHEN '2线' THEN 2 WHEN '3线' THEN 3
            WHEN '4线' THEN 4 WHEN 'VIP线' THEN 5
            WHEN '紫外' THEN 6 WHEN '紫外车间' THEN 6
            WHEN '工艺' THEN 7 WHEN '工艺组' THEN 7
            WHEN '设备' THEN 8 WHEN '设备组' THEN 8
            ELSE 99
          END, line
      `).all(...params);
      res.json(rows);
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  // 汇总统计（总工单数+完成率，支持年份和线体筛选）
  router.get('/stats/summary', requireAuth, (req, res) => {
    try {
      const { year, line } = req.query;
      let where = 'WHERE 1=1';
      const params = [];

      if (year && year !== '全部') {
        where += " AND strftime('%Y', report_date) = ?";
        params.push(String(year));
      }
      if (line && line !== '全部') {
        where += ' AND line = ?';
        params.push(String(line));
      }

      const rows = db.prepare(`
        SELECT
          COALESCE(work_order_type, '设备维修') as work_order_type,
          COUNT(*) as total,
          SUM(CASE WHEN status = '已完成' THEN 1 ELSE 0 END) as completed,
          ROUND(SUM(CASE WHEN status = '已完成' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) as completionRate
        FROM repairs
        ${where}
        GROUP BY COALESCE(work_order_type, '设备维修')
      `).all(...params);
      res.json(rows);
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  return router;
};
