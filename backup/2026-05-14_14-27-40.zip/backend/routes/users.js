const express = require('express');
const bcrypt = require('bcryptjs');

module.exports = function(db) {
  const router = express.Router();

  // ===== 中间件：检查登录状态 =====
  const requireAuth = (req, res, next) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ error: '未登录或会话已过期' });
    }
    next();
  };

  // ===== 中间件：检查管理员权限 =====
  const requireAdmin = (req, res, next) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ error: '未登录或会话已过期' });
    }
    if (req.session.role !== 'admin') {
      return res.status(403).json({ error: '无权限访问' });
    }
    next();
  };

  // ===== 登录 =====
  router.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: '用户名和密码不能为空' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }

    if (user.status === 'disabled') {
      return res.status(403).json({ error: '账号已被禁用，请联系管理员' });
    }

    const valid = bcrypt.compareSync(password, user.password);
    if (!valid) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }

    // 保存会话
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;

    // 更新最后活跃时间
    db.prepare("UPDATE users SET updated_at = datetime('now', 'localtime') WHERE id = ?").run(user.id);

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
      }
    });
  });

  // ===== 登出 =====
  router.post('/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: '登出失败' });
      }
      res.json({ success: true });
    });
  });

  // ===== 获取当前用户信息 =====
  router.get('/me', requireAuth, (req, res) => {
    const user = db.prepare('SELECT id, username, role, status, created_at FROM users WHERE id = ?').get(req.session.userId);
    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }
    res.json(user);
  });

  // ===== 检查会话是否有效 =====
  router.get('/check', (req, res) => {
    if (req.session && req.session.userId) {
      const user = db.prepare('SELECT id, username, role FROM users WHERE id = ? AND status = ?').get(req.session.userId, 'active');
      if (user) {
        // 刷新会话
        req.session.touch?.();
        return res.json({
          authenticated: true,
          user: {
            id: user.id,
            username: user.username,
            role: user.role,
          }
        });
      }
    }
    res.json({ authenticated: false });
  });

  // ===== 用户列表（仅管理员）=====
  router.get('/', requireAdmin, (req, res) => {
    const users = db.prepare('SELECT id, username, role, status, created_at, updated_at FROM users ORDER BY id ASC').all();
    res.json(users);
  });

  // ===== 新增用户（仅管理员）=====
  router.post('/', requireAdmin, (req, res) => {
    const { username, password, role } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: '用户名和密码不能为空' });
    }

    // 检查用户名是否已存在
    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    if (existing) {
      return res.status(400).json({ error: '用户名已存在' });
    }

    // 验证角色
    const userRole = (role === 'admin') ? 'admin' : 'user';

    // 加密密码
    const hashedPassword = bcrypt.hashSync(password, 10);

    try {
      const result = db.prepare('INSERT INTO users (username, password, role, status) VALUES (?, ?, ?, ?)').run(username, hashedPassword, userRole, 'active');
      res.json({ success: true, id: result.lastInsertRowid, message: '用户创建成功' });
    } catch (err) {
      res.status(500).json({ error: '创建用户失败' });
    }
  });

  // ===== 修改用户（仅管理员）=====
  router.put('/:id', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { role, status } = req.body;

    // 不能修改自己
    if (parseInt(id) === req.session.userId) {
      return res.status(400).json({ error: '不能修改自己的账号' });
    }

    const updates = [];
    const params = [];

    if (role && ['admin', 'user'].includes(role)) {
      updates.push('role = ?');
      params.push(role);
    }

    if (status && ['active', 'disabled'].includes(status)) {
      updates.push('status = ?');
      params.push(status);
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: '没有需要更新的字段' });
    }

    updates.push("updated_at = datetime('now', 'localtime')");
    params.push(id);

    try {
      db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...params);
      res.json({ success: true, message: '用户更新成功' });
    } catch (err) {
      res.status(500).json({ error: '更新用户失败' });
    }
  });

  // ===== 重置密码（仅管理员）=====
  router.post('/:id/reset-password', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { newPassword } = req.body;

    // 不能重置自己
    if (parseInt(id) === req.session.userId) {
      return res.status(400).json({ error: '不能重置自己的密码' });
    }

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: '密码长度至少6位' });
    }

    const hashedPassword = bcrypt.hashSync(newPassword, 10);

    try {
      db.prepare("UPDATE users SET password = ?, updated_at = datetime('now', 'localtime') WHERE id = ?").run(hashedPassword, id);
      res.json({ success: true, message: '密码重置成功' });
    } catch (err) {
      res.status(500).json({ error: '重置密码失败' });
    }
  });

  // ===== 删除用户（仅管理员）=====
  router.delete('/:id', requireAdmin, (req, res) => {
    const { id } = req.params;

    // 不能删除自己
    if (parseInt(id) === req.session.userId) {
      return res.status(400).json({ error: '不能删除自己的账号' });
    }

    // 检查是否为最后一个管理员
    const adminCount = db.prepare("SELECT COUNT(*) as count FROM users WHERE role = 'admin' AND status = 'active'").get().count;
    const targetUser = db.prepare('SELECT role FROM users WHERE id = ?').get(id);

    if (targetUser && targetUser.role === 'admin' && adminCount <= 1) {
      return res.status(400).json({ error: '不能删除最后一个管理员账号' });
    }

    try {
      db.prepare('DELETE FROM users WHERE id = ?').run(id);
      res.json({ success: true, message: '用户删除成功' });
    } catch (err) {
      res.status(500).json({ error: '删除用户失败' });
    }
  });

  // ===== 修改自己的密码 =====
  router.put('/change-password', requireAuth, (req, res) => {
    const { oldPassword, newPassword } = req.body;
    const userId = req.session.userId;

    if (!oldPassword || !newPassword) {
      return res.status(400).json({ error: '旧密码和新密码都不能为空' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: '新密码长度至少6位' });
    }

    const user = db.prepare('SELECT password FROM users WHERE id = ?').get(userId);
    if (!bcrypt.compareSync(oldPassword, user.password)) {
      return res.status(400).json({ error: '旧密码错误' });
    }

    const hashedPassword = bcrypt.hashSync(newPassword, 10);

    try {
      db.prepare("UPDATE users SET password = ?, updated_at = datetime('now', 'localtime') WHERE id = ?").run(hashedPassword, userId);
      res.json({ success: true, message: '密码修改成功' });
    } catch (err) {
      res.status(500).json({ error: '修改密码失败' });
    }
  });

  return router;
};
