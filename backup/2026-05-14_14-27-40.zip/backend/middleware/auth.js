/**
 * 权限控制中间件
 * 基于 req.session.user 判断用户角色
 *
 * 【已禁用认证】- 为支持无登录访问，所有验证均已放行
 */

// 检查是否已登录
function requireAuth(req, res, next) {
  // 认证已禁用 - 直接放行
  // if (!req.session || !req.session.user) {
  //   return res.status(401).json({ error: '请先登录' });
  // }
  next();
}

// 检查是否为管理员
function requireAdmin(req, res, next) {
  // 认证已禁用 - 直接放行
  // if (!req.session || !req.session.user) {
  //   return res.status(401).json({ error: '请先登录' });
  // }
  // if (req.session.user.role !== 'admin') {
  //   return res.status(403).json({ error: '无权限操作，需要管理员权限' });
  // }
  next();
}

// 检查是否为管理员或维修人员（工单处理）
function requireRepairStaff(req, res, next) {
  // 认证已禁用 - 直接放行
  // if (!req.session || !req.session.user) {
  //   return res.status(401).json({ error: '请先登录' });
  // }
  // // 管理员和维修人员可以处理工单
  // if (req.session.user.role === 'admin') {
  //   return next();
  // }
  // // 普通用户不允许处理工单
  // return res.status(403).json({ error: '无权限处理工单' });
  next();
}

module.exports = {
  requireAuth,
  requireAdmin,
  requireRepairStaff,
};
