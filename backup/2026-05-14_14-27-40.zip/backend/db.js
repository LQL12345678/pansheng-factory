const { DatabaseSync } = require('node:sqlite');
const path = require('path');

const db = new DatabaseSync(path.join(__dirname, 'db/equipment.db'));
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

function init() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS device_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      created_at TEXT DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS devices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      device_no TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      model TEXT,
      location TEXT NOT NULL,
      production_line TEXT,
      supplier TEXT,
      install_date TEXT,
      maintenance_cycle_days INTEGER DEFAULT 30,
      responsible_person TEXT,
      status TEXT DEFAULT '正常',
      remarks TEXT,
      qr_url TEXT,
      created_at TEXT DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT DEFAULT (datetime('now', 'localtime'))
    );

    -- 迁移：修改repairs表（仅当缺少 work_order_type 列时执行）
    -- 已有新结构的数据库跳过此迁移
  `);
  try {
    const existingCols = db.prepare("PRAGMA table_info(repairs)").all();
    const hasWorkOrderType = existingCols.some(c => c.name === 'work_order_type');
    if (hasWorkOrderType) {
      console.log('  迁移跳过: repairs 表已是新结构');
    } else {
      db.exec(`
        CREATE TABLE IF NOT EXISTS repairs_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          work_order_no TEXT UNIQUE,
          report_date TEXT NOT NULL,
          report_time TEXT,
          device_id INTEGER,
          line TEXT,
          reporter TEXT,
          area TEXT,
          fault_desc TEXT NOT NULL,
          fault_type TEXT,
          fault_cause TEXT,
          solution TEXT,
          parts_used TEXT,
          repairman TEXT,
          accept_time TEXT,
          finish_time TEXT,
          duration_minutes INTEGER,
          stop_duration_minutes INTEGER,
          status TEXT DEFAULT '待处理',
          remarks TEXT,
          work_order_type TEXT DEFAULT '设备维修',
          created_at TEXT DEFAULT (datetime('now', 'localtime'))
        );
      `);
      try {
        db.exec(`
          INSERT OR IGNORE INTO repairs_new (id, report_date, device_id, line, reporter, area, fault_desc, fault_type, solution, repairman, status, remarks, created_at)
          SELECT id, report_date, device_id, line, reporter, area,
            COALESCE(fault_desc, problem_desc),
            fault_type,
            solution,
            COALESCE(repairman, handler),
            COALESCE(status, '待处理'),
            '',
            COALESCE(created_at, datetime('now', 'localtime'))
          FROM repairs;
          DROP TABLE IF EXISTS repairs;
          ALTER TABLE repairs_new RENAME TO repairs;
        `);
        console.log('  迁移: repairs 表结构升级');
      } catch (e) {
        console.log('  迁移跳过:', e.message);
        db.exec('DROP TABLE IF EXISTS repairs_new');
      }
    }
  } catch (e) {
    console.log('  迁移检查跳过:', e.message);
    db.exec('DROP TABLE IF EXISTS repairs_new');
  }
  db.exec(`

    CREATE TABLE IF NOT EXISTS parts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      part_no TEXT UNIQUE,
      name TEXT NOT NULL,
      spec TEXT NOT NULL,
      brand TEXT,
      applicable_devices TEXT,
      storage_location TEXT NOT NULL,
      stock INTEGER NOT NULL DEFAULT 0,
      safety_stock INTEGER NOT NULL,
      unit TEXT DEFAULT '个',
      unit_price REAL,
      supplier TEXT,
      purchase_cycle_days INTEGER,
      remarks TEXT,
      created_at TEXT DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS inventory_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      log_no TEXT UNIQUE,
      log_date TEXT NOT NULL,
      part_id INTEGER NOT NULL,
      operation_type TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      related_work_order TEXT,
      handler TEXT NOT NULL,
      remarks TEXT,
      created_at TEXT DEFAULT (datetime('now', 'localtime')),
      FOREIGN KEY (part_id) REFERENCES parts(id)
    );

    CREATE TABLE IF NOT EXISTS maintenance_plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      plan_no TEXT UNIQUE,
      device_id INTEGER,
      maintenance_type TEXT NOT NULL,
      task_desc TEXT NOT NULL,
      plan_date TEXT NOT NULL,
      responsible_person TEXT NOT NULL,
      wechat_id TEXT,
      required_parts TEXT,
      estimated_duration INTEGER,
      actual_date TEXT,
      status TEXT DEFAULT '待执行',
      executor TEXT,
      remarks TEXT,
      created_at TEXT DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS wechat_notification_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      notification_type TEXT NOT NULL,
      target_user TEXT NOT NULL,
      title TEXT,
      content TEXT NOT NULL,
      related_id INTEGER,
      status TEXT DEFAULT 'pending',
      error_msg TEXT,
      sent_at TEXT,
      created_at TEXT DEFAULT (datetime('now', 'localtime'))
    );

    INSERT OR IGNORE INTO device_categories (name) VALUES
      ('提升机'),('平移机'),('倍速链'),('皮带线'),('阻挡器'),
      ('打印机'),('AGV'),('空压机'),('冲压机'),('升降机'),
      ('老化架'),('滚筒线'),('打包机');

    -- 保养计划更换零部件记录
    CREATE TABLE IF NOT EXISTS maintenance_parts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      maintenance_plan_id INTEGER NOT NULL,
      part_id INTEGER NOT NULL,
      part_name TEXT NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now', 'localtime')),
      FOREIGN KEY (maintenance_plan_id) REFERENCES maintenance_plans(id) ON DELETE CASCADE,
      FOREIGN KEY (part_id) REFERENCES parts(id)
    );
  `);
  // 迁移：repairs 表 repairman 去掉 NOT NULL（已在新结构中处理，此处仅作兼容）
  try {
    const cols = db.prepare("PRAGMA table_info(repairs)").all();
    const rmCol = cols.find(c => c.name === 'repairman');
    if (rmCol && rmCol.notnull === 1) {
      db.exec(`
        CREATE TABLE repairs_no_nn (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          work_order_no TEXT UNIQUE,
          report_date TEXT NOT NULL,
          report_time TEXT,
          device_id INTEGER,
          line TEXT,
          reporter TEXT,
          area TEXT,
          fault_desc TEXT NOT NULL,
          fault_type TEXT,
          fault_cause TEXT,
          solution TEXT,
          parts_used TEXT,
          repairman TEXT,
          accept_time TEXT,
          finish_time TEXT,
          duration_minutes INTEGER,
          stop_duration_minutes INTEGER,
          status TEXT DEFAULT '待处理',
          remarks TEXT,
          work_order_type TEXT DEFAULT '设备维修',
          created_at TEXT DEFAULT (datetime('now', 'localtime'))
        );
        INSERT INTO repairs_no_nn SELECT * FROM repairs;
        DROP TABLE repairs;
        ALTER TABLE repairs_no_nn RENAME TO repairs;
      `);
      console.log('  迁移: repairs.repairman 去掉 NOT NULL');
    }
  } catch (e) {
    console.log('  迁移跳过:', e.message);
  }
  // 迁移：为 inventory_logs 增加领用专用字段（已有列时忽略报错）
  try { db.exec('ALTER TABLE inventory_logs ADD COLUMN line TEXT'); } catch (_) {}
  try { db.exec('ALTER TABLE inventory_logs ADD COLUMN purpose TEXT'); } catch (_) {}

  // 迁移：repairs 表新增 work_order_type 字段
  try {
    db.exec('ALTER TABLE repairs ADD COLUMN work_order_type TEXT DEFAULT "设备维修"');
    console.log('  迁移: repairs 新增 work_order_type 字段');
  } catch (e) {
    // 字段已存在则忽略
  }

  // 迁移：新建 repair_parts 表（工单更换零件明细）
  db.exec(`
    CREATE TABLE IF NOT EXISTS repair_parts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      repair_id INTEGER NOT NULL,
      part_id INTEGER NOT NULL,
      part_name TEXT NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now', 'localtime')),
      FOREIGN KEY (repair_id) REFERENCES repairs(id) ON DELETE CASCADE,
      FOREIGN KEY (part_id) REFERENCES parts(id)
    )
  `);

  // ===== 设备变更记录表（采购/报废）=====
  db.exec(`
    CREATE TABLE IF NOT EXISTS device_change_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      device_id INTEGER NOT NULL,
      device_no TEXT NOT NULL,
      device_name TEXT NOT NULL,
      change_type TEXT NOT NULL,
      change_date TEXT NOT NULL,
      operator TEXT NOT NULL,
      reason TEXT,
      remarks TEXT,
      created_at TEXT DEFAULT (datetime('now', 'localtime')),
      FOREIGN KEY (device_id) REFERENCES devices(id)
    )
  `);

  // 迁移：为现有设备回填采购记录（仅回填没有采购记录的设备）
  try {
    const allDevices = db.prepare('SELECT id, device_no, name, install_date, created_at FROM devices').all();
    for (const dev of allDevices) {
      const exists = db.prepare('SELECT 1 FROM device_change_records WHERE device_id=? AND change_type=?').get(dev.id, '采购');
      if (!exists) {
        const changeDate = dev.install_date || dev.created_at || new Date().toISOString().slice(0, 19).replace('T', ' ');
        db.prepare(`
          INSERT INTO device_change_records (device_id, device_no, device_name, change_type, change_date, operator)
          VALUES (?, ?, ?, '采购', ?, '')
        `).run(dev.id, dev.device_no, dev.name, changeDate);
      }
    }
    console.log(`  迁移: 回填 ${allDevices.length} 台设备的采购记录`);
  } catch (e) {
    console.log('  采购记录回填跳过:', e.message);
  }

  // ===== 工具台账 =====
  // 迁移：如果旧 tools 表包含 tool_no 列（旧结构），则删除重建
  try {
    const toolCols = db.prepare("PRAGMA table_info(tools)").all();
    if (toolCols.length > 0 && toolCols.some(c => c.name === 'tool_no')) {
      db.exec('DROP TABLE IF EXISTS tool_change_records');
      db.exec('DROP TABLE IF EXISTS tools');
      db.exec('DROP TABLE IF EXISTS tool_categories');
      console.log('  迁移: tools 表结构重建（旧字段→新字段）');
    }
  } catch (e) {
    // 表不存在则忽略
  }

  // 迁移：为已有 tools 表添加 quantity 列
  try {
    const toolCols2 = db.prepare("PRAGMA table_info(tools)").all();
    if (toolCols2.length > 0 && !toolCols2.some(c => c.name === 'quantity')) {
      db.exec("ALTER TABLE tools ADD COLUMN quantity INTEGER DEFAULT 1");
      console.log('  迁移: tools 表新增 quantity 字段');
    }
  } catch (e) {
    // 忽略
  }

  db.exec(`
    CREATE TABLE IF NOT EXISTS tools (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      line TEXT DEFAULT '',
      model TEXT DEFAULT '',
      device_no TEXT DEFAULT '',
      station TEXT DEFAULT '',
      quantity INTEGER DEFAULT 1,
      status TEXT DEFAULT '正常',
      created_at TEXT DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS tool_change_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tool_id INTEGER NOT NULL,
      tool_name TEXT NOT NULL,
      change_type TEXT NOT NULL,
      change_date TEXT NOT NULL,
      operator TEXT NOT NULL,
      reason TEXT,
      remarks TEXT,
      created_at TEXT DEFAULT (datetime('now', 'localtime')),
      FOREIGN KEY (tool_id) REFERENCES tools(id)
    )
  `);

  console.log('✅ 数据库初始化完成');
}

// ===== 用户表初始化和默认管理员 =====
function initUsers() {
  const bcrypt = require('bcryptjs');
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'user')),
      status TEXT DEFAULT 'active' CHECK(status IN ('active', 'disabled')),
      created_at TEXT DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT DEFAULT (datetime('now', 'localtime'))
    )
  `);

  // 创建默认管理员
  const existingAdmin = db.prepare('SELECT id FROM users WHERE username = ?').get('admin');
  if (!existingAdmin) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    db.prepare('INSERT INTO users (username, password, role, status) VALUES (?, ?, ?, ?)').run('admin', hashedPassword, 'admin', 'active');
    console.log('  ✅ 默认管理员账号创建: admin / admin123');
  }
}

// 在 init 末尾调用
initUsers();

module.exports = { db, init, initUsers };
