const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const session = require('express-session');
const { db, init } = require('./db');

const app = express();
app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json());

// Session 配置：8小时会话，30分钟无操作过期
app.use(session({
  secret: 'equipment-management-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 8 * 60 * 60 * 1000, // 8小时
    httpOnly: true,
    sameSite: 'lax',
  },
}));

// 30分钟无操作自动登出（通过滑动过期实现）
app.use((req, res, next) => {
  if (req.session && req.session.userId) {
    const lastActivity = req.session.lastActivity || Date.now();
    const idleTime = Date.now() - lastActivity;
    if (idleTime > 30 * 60 * 1000) { // 30分钟
      req.session.destroy();
      return res.status(401).json({ error: '会话已过期，请重新登录' });
    }
    req.session.lastActivity = Date.now();
  }
  next();
});

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 初始化数据库（包含用户表初始化）
init();

// 上传配置
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'uploads')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// ===== 通用工具：Excel日期序列号转日期字符串 =====
function excelDateToString(val) {
  if (!val) return '';
  if (typeof val === 'string') return val;
  // Excel序列号转JS日期
  const d = new Date(Math.round((val - 25569) * 86400 * 1000));
  return d.toISOString().split('T')[0];
}

// ===== 用户路由（登录、登出、用户管理）=====
const userRouter = require('./routes/users')(db);
app.use('/api/auth', userRouter);

// ===== 设备路由 =====
const deviceRouter = require('./routes/devices')(db, upload, excelDateToString);
app.use('/api/devices', deviceRouter);

// ===== 维修工单路由 =====
const repairRouter = require('./routes/repairs')(db, excelDateToString);
app.use('/api/repairs', repairRouter);

// ===== 零部件路由 =====
const partRouter = require('./routes/parts')(db, upload, excelDateToString);
app.use('/api/parts', partRouter);

// ===== 工具台账路由 =====
const toolRouter = require('./routes/tools')(db, upload, excelDateToString);
app.use('/api/tools', toolRouter);

// ===== 保养计划路由 =====
const maintenanceRouter = require('./routes/maintenance')(db, excelDateToString);
app.use('/api/maintenance', maintenanceRouter);

// ===== 统计看板 =====
app.get('/api/stats/overview', (req, res) => {
  const deviceCount = db.prepare('SELECT COUNT(*) as count FROM devices').get().count;
  const repairCount = db.prepare("SELECT COUNT(*) as count FROM repairs WHERE status != '已完成'").get().count;
  const partCount = db.prepare('SELECT COUNT(*) as count FROM parts').get().count;
  const lowStockCount = db.prepare('SELECT COUNT(*) as count FROM parts WHERE stock < safety_stock').get().count;
  res.json({ deviceCount, repairCount, partCount, lowStockCount });
});

// 故障频率统计
app.get('/api/stats/fault-frequency', (req, res) => {
  const rows = db.prepare(`
    SELECT d.name as deviceName, d.device_no as deviceNo,
           COUNT(r.id) as faultCount,
           ROUND(AVG(r.duration_minutes), 1) as avgDuration
    FROM repairs r
    JOIN devices d ON d.id = r.device_id
    WHERE r.created_at >= datetime('now', '-90 day')
    GROUP BY r.device_id
    ORDER BY faultCount DESC
    LIMIT 20
  `).all();
  res.json(rows);
});

// 故障类型分布
app.get('/api/stats/fault-types', (req, res) => {
  const rows = db.prepare(`
    SELECT fault_type as name, COUNT(*) as value
    FROM repairs
    WHERE fault_type IS NOT NULL AND created_at >= datetime('now', '-90 day')
    GROUP BY fault_type
    ORDER BY value DESC
  `).all();
  res.json(rows);
});

// 低库存列表
app.get('/api/stats/low-stock', (req, res) => {
  const rows = db.prepare(`
    SELECT part_no, name, spec, stock, safety_stock, storage_location
    FROM parts WHERE stock < safety_stock
    ORDER BY stock ASC
  `).all();
  res.json(rows);
});

// ===== 数据版本检查（用于智能刷新）=====
app.get('/api/data-version', (req, res) => {
  const devicesVersion = db.prepare("SELECT MAX(updated_at) as version FROM devices").get()?.version || '';
  const repairsVersion = db.prepare("SELECT MAX(updated_at) as version FROM repairs").get()?.version || '';
  const partsVersion = db.prepare("SELECT MAX(updated_at) as version FROM parts").get()?.version || '';
  res.json({
    devices: devicesVersion,
    repairs: repairsVersion,
    parts: partsVersion,
    timestamp: Date.now()
  });
});

const PORT = 3001;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 设备管理系统后端启动成功：http://localhost:${PORT}`);
  console.log(`📱 局域网访问：http://<你的IP>:${PORT}`);
});
