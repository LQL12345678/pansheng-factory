import { useState, useEffect, useRef, ChangeEvent } from 'react';
import * as XLSX from 'xlsx';
import { useLocation } from 'react-router-dom';
import { partApi } from '../services/api';
import { Part } from '../types';
import DeleteConfirmWithPassword from '../components/DeleteConfirmWithPassword';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';

// 预设线体选项
const LINE_OPTIONS = ['1线', '2线', '3线', '4线', 'VIP线', '紫外', '仓储', '其他'];

export default function PartList() {
  const location = useLocation();
  const [list, setList] = useState<Part[]>([]);
  const [keyword, setKeyword] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState<Part | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState<Partial<Part>>({});
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Part | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [nextNo, setNextNo] = useState('');

  // 行内编辑库存
  const [inlineEditId, setInlineEditId] = useState<number | null>(null);
  const [inlineStockVal, setInlineStockVal] = useState<string>('');
  const inlineInputRef = useRef<HTMLInputElement>(null);

  // 领用弹窗
  const [usageItem, setUsageItem] = useState<Part | null>(null);
  const [usageForm, setUsageForm] = useState<{
    handler: string; line: string; quantity: string;
    log_date: string; purpose: string; remarks: string;
  }>({ handler: '', line: '', quantity: '1', log_date: today(), purpose: '', remarks: '' });

  // 入库弹窗
  const [stockinItem, setStockinItem] = useState<Part | null>(null);
  const [stockinForm, setStockinForm] = useState<{
    quantity: string; log_date: string; handler: string; remarks: string;
  }>({ quantity: '1', log_date: today(), handler: '', remarks: '' });

  // 记录弹窗
  const [showLogs, setShowLogs] = useState(false);
  const [logsTab, setLogsTab] = useState<'usage' | 'stockin'>('usage');
  const [usageLogs, setUsageLogs] = useState<any[]>([]);
  const [stockinLogs, setStockinLogs] = useState<any[]>([]);
  const [logsKeyword, setLogsKeyword] = useState('');
  const [logsStartDate, setLogsStartDate] = useState('');
  const [logsEndDate, setLogsEndDate] = useState('');
  const [logsLoading, setLogsLoading] = useState(false);

  // 锁定背景滚动（弹窗打开时）
  useBodyScrollLock(showForm || !!confirmDelete || !!usageItem || !!stockinItem || showLogs);

  function today() {
    return new Date().toISOString().slice(0, 10);
  }

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const load = (kw?: string) => partApi.list(kw).then(r => {
    setList([...r.data]);
  });

  useEffect(() => {
    load();
    if (location?.pathname === '/parts/add') {
      setShowForm(true);
      setEditItem(null);
      setFormData({ unit: '个', safety_stock: 5, stock: 0 });
      partApi.nextNo().then(r => setNextNo(r.data?.next_no || '')).catch(() => {});
    }
    if (location?.pathname === '/parts/withdraw') {
      setShowForm(false);
      setEditItem(null);
    }
  }, [location?.pathname]);

  // 定时刷新数据
  useEffect(() => {
    const interval = setInterval(() => {
      load(keyword);
    }, 30000);
    return () => clearInterval(interval);
  }, [keyword]);

  useEffect(() => {
    if (editItem) setFormData({ ...editItem });
    else setFormData({ unit: '个', safety_stock: 5, stock: 0 });
  }, [editItem]);

  // ===== 搜索 =====
  const handleSearch = () => load(keyword);
  const handleReset = () => { setKeyword(''); load(); };

  // ===== 行内库存编辑 =====
  const startInlineEdit = (item: Part) => {
    setInlineEditId(item.id!);
    setInlineStockVal(String(item.stock));
    setTimeout(() => inlineInputRef.current?.focus(), 30);
  };
  const commitInlineEdit = async (item: Part) => {
    const newStock = Number(inlineStockVal);
    if (isNaN(newStock) || newStock === item.stock) { setInlineEditId(null); return; }
    try {
      await partApi.patchStock(String(item.id), newStock);
      setList(prev => prev.map(p => p.id === item.id ? { ...p, stock: newStock } : p));
      showToast(`库存已更新：${item.name} → ${newStock} ${item.unit || '个'}`, 'success');
    } catch (err: any) {
      showToast('更新失败：' + (err.response?.data?.error || err.message), 'error');
    }
    setInlineEditId(null);
  };

  // ===== 新增/编辑表单 =====
  const handleInputChange = (e: ChangeEvent<HTMLInputElement & HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const isEdit = !!editItem?.id;
    setSubmitting(true);
    try {
      const data: any = { ...formData };
      data.stock = Number(data.stock);
      data.safety_stock = Number(data.safety_stock);
      data.unit_price = data.unit_price ? Number(data.unit_price) : null;
      data.purchase_cycle_days = data.purchase_cycle_days ? Number(data.purchase_cycle_days) : null;
      if (isEdit) await partApi.update(String(editItem!.id), data);
      else await partApi.create(data);
      setShowForm(false); setEditItem(null); setFormData({});
      await load(keyword || undefined);
      showToast(isEdit ? '更新成功！' : '创建成功！', 'success');
    } catch (err: any) {
      showToast('保存失败：' + (err.response?.data?.error || err.message || '未知错误'), 'error');
    } finally { setSubmitting(false); }
  };

  // ===== 删除 =====
  const doDelete = async () => {
    if (!confirmDelete?.id) return;
    setSubmitting(true);
    try {
      await partApi.delete(String(confirmDelete.id));
      setConfirmDelete(null);
      await load(keyword || undefined);
      showToast('删除成功！', 'success');
    } catch (err: any) {
      showToast('删除失败：' + (err.response?.data?.error || err.message), 'error');
      setConfirmDelete(null);
    } finally { setSubmitting(false); }
  };

  // ===== 领用 =====
  const openUsage = (item: Part) => {
    setUsageItem(item);
    setUsageForm({ handler: '', line: '', quantity: '1', log_date: today(), purpose: '', remarks: '' });
  };
  const handleUsageChange = (e: ChangeEvent<HTMLInputElement & HTMLSelectElement>) => {
    const { name, value } = e.target;
    setUsageForm(prev => ({ ...prev, [name]: value }));
  };
  const submitUsage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!usageItem) return;
    const qty = Number(usageForm.quantity);
    if (!qty || qty <= 0) { showToast('领用数量必须大于 0', 'error'); return; }
    setSubmitting(true);
    try {
      const res = await partApi.usage({
        part_id: usageItem.id,
        quantity: qty,
        handler: usageForm.handler,
        line: usageForm.line,
        log_date: usageForm.log_date,
        purpose: usageForm.purpose,
        remarks: usageForm.remarks,
      });
      setList(prev => prev.map(p => p.id === usageItem.id ? { ...p, stock: res.data.stock } : p));
      setUsageItem(null);
      showToast(`领用成功！${usageItem.name} 剩余库存：${res.data.stock} ${usageItem.unit || '个'}`, 'success');
    } catch (err: any) {
      showToast(err.response?.data?.error || '领用失败', 'error');
    } finally { setSubmitting(false); }
  };

  // ===== 入库 =====
  const openStockin = (item: Part) => {
    setStockinItem(item);
    setStockinForm({ quantity: '1', log_date: today(), handler: '', remarks: '' });
  };
  const handleStockinChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setStockinForm(prev => ({ ...prev, [name]: value }));
  };
  const submitStockin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stockinItem) return;
    const qty = Number(stockinForm.quantity);
    if (!qty || qty <= 0) { showToast('入库数量必须大于 0', 'error'); return; }
    setSubmitting(true);
    try {
      const res = await partApi.stockin({
        part_id: stockinItem.id,
        quantity: qty,
        handler: stockinForm.handler,
        log_date: stockinForm.log_date,
        remarks: stockinForm.remarks,
      });
      setList(prev => prev.map(p => p.id === stockinItem.id ? { ...p, stock: res.data.stock } : p));
      setStockinItem(null);
      showToast(`入库成功！${stockinItem.name} 当前库存：${res.data.stock} ${stockinItem.unit || '个'}`, 'success');
    } catch (err: any) {
      showToast(err.response?.data?.error || '入库失败', 'error');
    } finally { setSubmitting(false); }
  };

  // ===== 记录查询 =====
  const loadLogs = async () => {
    setLogsLoading(true);
    try {
      const params = {
        keyword: logsKeyword || undefined,
        start_date: logsStartDate || undefined,
        end_date: logsEndDate || undefined,
      };
      const [uRes, sRes] = await Promise.all([
        partApi.usageLogs(params),
        partApi.stockinLogs(params),
      ]);
      setUsageLogs(uRes.data);
      setStockinLogs(sRes.data);
    } catch (err: any) {
      showToast('加载记录失败', 'error');
    } finally { setLogsLoading(false); }
  };
  const openLogs = () => { setShowLogs(true); loadLogs(); };

  // ===== 导入/导出 =====
  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const result = await partApi.importExcel(file);
      showToast(`导入完成！成功: ${result.data?.imported || 0}，跳过: ${result.data?.skipped || 0}`, 'success');
      load(keyword || undefined);
    } catch (err: any) {
      showToast('导入失败：' + (err.message || '文件格式错误'), 'error');
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleExport = () => {
    const exportData = list.map((item: Part) => ({
      '备件编号': item.part_no, '备件名称': item.name, '规格型号': item.spec,
      '品牌': item.brand, '适用设备': item.applicable_devices,
      '存放位置': item.storage_location, '当前库存': item.stock,
      '安全库存': item.safety_stock, '单位': item.unit, '单价': item.unit_price,
      '供应商': item.supplier, '采购周期(天)': item.purchase_cycle_days, '备注': item.remarks,
    }));
    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '备件台账');
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([wbout], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = '备件台账导出.xlsx'; a.click();
    URL.revokeObjectURL(url);
  };

  // ===== 通用弹窗样式 =====
  const modalStyle: React.CSSProperties = { maxWidth: 480 };
  const fieldStyle: React.CSSProperties = { marginBottom: 14 };
  const labelStyle: React.CSSProperties = { display: 'block', fontSize: 13, color: '#666', marginBottom: 4 };
  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '7px 10px', borderRadius: 6,
    border: '1px solid #d9d9d9', fontSize: 14, boxSizing: 'border-box',
  };
  const btnRowStyle: React.CSSProperties = {
    display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 20
  };

  return (
    <div style={{ position: 'relative' }}>
      {/* ===== Toast ===== */}
      {toast && (
        <div style={{
          position: 'fixed', top: 20, right: 20, zIndex: 9999,
          padding: '12px 20px', borderRadius: 8,
          background: toast.type === 'success' ? '#52c41a' : '#ff4d4f',
          color: '#fff', fontWeight: 600, fontSize: 14,
          boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
          animation: 'fadeIn 0.2s ease', maxWidth: 360,
        }}>
          {toast.msg}
        </div>
      )}

      {/* ===== 删除确认 ===== */}
      <DeleteConfirmWithPassword
        visible={!!confirmDelete}
        itemName={confirmDelete?.name}
        loading={submitting}
        onConfirm={doDelete}
        onCancel={() => setConfirmDelete(null)}
      />

      {/* ===== 领用弹窗 ===== */}
      {usageItem && (
        <div className="modal-overlay">
          <div className="modal" style={modalStyle}>
            <h3 style={{ marginTop: 0 }}>领用备件</h3>
            <p style={{ margin: '4px 0 16px', color: '#555', fontSize: 13 }}>
              {usageItem.name}（{usageItem.spec}）&nbsp;&nbsp;
              当前库存：<strong style={{ color: usageItem.stock <= 0 ? '#ff4d4f' : '#1677ff' }}>
                {usageItem.stock} {usageItem.unit || '个'}
              </strong>
            </p>
            <form onSubmit={submitUsage}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 16px' }}>
                <div style={fieldStyle}>
                  <label style={labelStyle}>领用人 *</label>
                  <input style={inputStyle} name="handler" value={usageForm.handler}
                    onChange={handleUsageChange} required placeholder="请输入姓名" />
                </div>
                <div style={fieldStyle}>
                  <label style={labelStyle}>领用数量 *</label>
                  <input style={inputStyle} name="quantity" type="number" min={1}
                    value={usageForm.quantity} onChange={handleUsageChange} required />
                </div>
                <div style={fieldStyle}>
                  <label style={labelStyle}>线体 *</label>
                  <select style={inputStyle} name="line" value={usageForm.line}
                    onChange={handleUsageChange as any} required>
                    <option value="">请选择</option>
                    {LINE_OPTIONS.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                </div>
                <div style={fieldStyle}>
                  <label style={labelStyle}>领用日期 *</label>
                  <input style={inputStyle} name="log_date" type="date"
                    value={usageForm.log_date} onChange={handleUsageChange} required />
                </div>
                <div style={{ ...fieldStyle, gridColumn: '1/-1' }}>
                  <label style={labelStyle}>用途</label>
                  <input style={inputStyle} name="purpose" value={usageForm.purpose}
                    onChange={handleUsageChange} placeholder="领用原因描述（可选）" />
                </div>
                <div style={{ ...fieldStyle, gridColumn: '1/-1' }}>
                  <label style={labelStyle}>备注</label>
                  <input style={inputStyle} name="remarks" value={usageForm.remarks}
                    onChange={handleUsageChange} placeholder="补充说明（可选）" />
                </div>
              </div>
              <div style={btnRowStyle}>
                <button type="button" onClick={() => setUsageItem(null)}>取消</button>
                <button type="submit" className="primary" disabled={submitting}>
                  {submitting ? '提交中...' : '确认领用'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===== 入库弹窗 ===== */}
      {stockinItem && (
        <div className="modal-overlay">
          <div className="modal" style={modalStyle}>
            <h3 style={{ marginTop: 0 }}>备件入库</h3>
            <p style={{ margin: '4px 0 16px', color: '#555', fontSize: 13 }}>
              {stockinItem.name}（{stockinItem.spec}）&nbsp;&nbsp;
              当前库存：<strong style={{ color: '#1677ff' }}>{stockinItem.stock} {stockinItem.unit || '个'}</strong>
            </p>
            <form onSubmit={submitStockin}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 16px' }}>
                <div style={fieldStyle}>
                  <label style={labelStyle}>入库数量 *</label>
                  <input style={inputStyle} name="quantity" type="number" min={1}
                    value={stockinForm.quantity} onChange={handleStockinChange} required />
                </div>
                <div style={fieldStyle}>
                  <label style={labelStyle}>入库日期 *</label>
                  <input style={inputStyle} name="log_date" type="date"
                    value={stockinForm.log_date} onChange={handleStockinChange} required />
                </div>
                <div style={{ ...fieldStyle, gridColumn: '1/-1' }}>
                  <label style={labelStyle}>录入人 *</label>
                  <input style={inputStyle} name="handler" value={stockinForm.handler}
                    onChange={handleStockinChange} required placeholder="请输入姓名" />
                </div>
                <div style={{ ...fieldStyle, gridColumn: '1/-1' }}>
                  <label style={labelStyle}>备注</label>
                  <input style={inputStyle} name="remarks" value={stockinForm.remarks}
                    onChange={handleStockinChange} placeholder="补充说明（可选）" />
                </div>
              </div>
              <div style={btnRowStyle}>
                <button type="button" onClick={() => setStockinItem(null)}>取消</button>
                <button type="submit" className="primary" disabled={submitting}>
                  {submitting ? '提交中...' : '确认入库'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===== 领用/入库记录弹窗 ===== */}
      {showLogs && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 900, width: '92vw' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3 style={{ margin: 0 }}>领用 / 入库记录</h3>
              <button type="button" onClick={() => setShowLogs(false)}
                style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#999' }}>✕</button>
            </div>
            {/* Tab */}
            <div style={{ display: 'flex', gap: 0, marginBottom: 14, borderBottom: '2px solid #f0f0f0' }}>
              {(['usage', 'stockin'] as const).map(tab => (
                <button key={tab} type="button" onClick={() => setLogsTab(tab)}
                  style={{
                    padding: '8px 20px', border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: 14,
                    background: 'none',
                    borderBottom: logsTab === tab ? '2px solid #1677ff' : '2px solid transparent',
                    color: logsTab === tab ? '#1677ff' : '#666',
                    marginBottom: -2,
                  }}>
                  {tab === 'usage' ? '领用记录' : '入库记录'}
                </button>
              ))}
            </div>
            {/* 筛选 */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
              <input placeholder="搜索备件名称/编号/人员" value={logsKeyword}
                onChange={e => setLogsKeyword(e.target.value)}
                style={{ ...inputStyle, width: 200 }} />
              <input type="date" value={logsStartDate} onChange={e => setLogsStartDate(e.target.value)}
                style={{ ...inputStyle, width: 150 }} title="开始日期" />
              <span style={{ lineHeight: '34px', color: '#999' }}>—</span>
              <input type="date" value={logsEndDate} onChange={e => setLogsEndDate(e.target.value)}
                style={{ ...inputStyle, width: 150 }} title="结束日期" />
              <button className="primary" onClick={loadLogs} style={{ padding: '7px 16px' }}>查询</button>
              <button onClick={() => { setLogsKeyword(''); setLogsStartDate(''); setLogsEndDate(''); }}
                style={{ padding: '7px 16px' }}>重置</button>
            </div>
            {/* 表格 */}
            {logsLoading ? (
              <div style={{ textAlign: 'center', padding: 40, color: '#999' }}>加载中...</div>
            ) : logsTab === 'usage' ? (
              <div style={{ overflowX: 'auto', maxHeight: '55vh', overflowY: 'auto' }}>
                <table style={{ width: '100%', fontSize: 13 }}>
                  <thead>
                    <tr>
                      <th>备件名称</th><th>备件编号</th><th>领用人</th><th>线体</th>
                      <th>领用日期</th><th>数量</th><th>用途</th><th>备注</th>
                    </tr>
                  </thead>
                  <tbody>
                    {usageLogs.length === 0 ? (
                      <tr><td colSpan={8} style={{ textAlign: 'center', color: '#aaa', padding: 24 }}>暂无记录</td></tr>
                    ) : usageLogs.map(r => (
                      <tr key={r.id}>
                        <td>{r.part_name}</td>
                        <td className="monospace">{r.part_no_ref}</td>
                        <td>{r.handler}</td>
                        <td>{r.line}</td>
                        <td>{r.log_date}</td>
                        <td>{r.quantity} {r.part_unit}</td>
                        <td>{r.purpose}</td>
                        <td>{r.remarks}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div style={{ overflowX: 'auto', maxHeight: '55vh', overflowY: 'auto' }}>
                <table style={{ width: '100%', fontSize: 13 }}>
                  <thead>
                    <tr>
                      <th>备件名称</th><th>备件编号</th><th>入库数量</th>
                      <th>入库日期</th><th>录入人</th><th>备注</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stockinLogs.length === 0 ? (
                      <tr><td colSpan={6} style={{ textAlign: 'center', color: '#aaa', padding: 24 }}>暂无记录</td></tr>
                    ) : stockinLogs.map(r => (
                      <tr key={r.id}>
                        <td>{r.part_name}</td>
                        <td className="monospace">{r.part_no_ref}</td>
                        <td>{r.quantity} {r.part_unit}</td>
                        <td>{r.log_date}</td>
                        <td>{r.handler}</td>
                        <td>{r.remarks}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ===== 工具栏 ===== */}
      <div className="toolbar" style={{ flexWrap: 'wrap', gap: 10, alignItems: 'center' }}>
        <button className="primary" onClick={() => {
          setEditItem(null); setFormData({ unit: '个', safety_stock: 5, stock: 0 }); partApi.nextNo().then(r => setNextNo(r.data?.next_no || '')).catch(() => {}); setShowForm(true);
        }}>＋ 新增备件</button>
        <button className="btn-outline-default" onClick={() => fileRef.current?.click()}>导入Excel</button>
        <input ref={fileRef} type="file" accept=".xlsx,.xls" style={{ display: 'none' }} onChange={handleImport} />
        <button className="btn-outline-primary" onClick={openLogs}>📋 领用/入库记录</button>
        <button className="btn-outline-default" onClick={handleExport}>导出Excel</button>
        {/* 搜索区域 */}
        <div className="toolbar-search">
          <input
            placeholder="搜索编号/名称/规格/品牌/位置"
            value={keyword}
            onChange={e => setKeyword(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            className="search-input"
          />
          <button onClick={handleSearch} className="primary">搜索</button>
          <button onClick={handleReset} className="btn-text">重置</button>
        </div>
      </div>

      {/* ===== 主表格 ===== */}
      <div className="card">
        <table>
          <thead>
            <tr>
              <th style={{ width: 48, textAlign: 'center' }}>序号</th>
              <th>备件编号</th><th>名称</th><th>规格</th>
              <th title="点击数字可直接修改库存">库存 ✏️</th>
              <th>安全库存</th><th>位置</th><th>品牌</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            {list.length === 0 ? (
              <tr><td colSpan={9} style={{ textAlign: 'center', color: '#aaa', padding: 32 }}>
                {keyword ? '未找到匹配备件，请尝试其他关键字' : '暂无备件数据'}
              </td></tr>
            ) : list.map((d, index) => (
              <tr key={d.id}>
                <td style={{ textAlign: 'center', color: '#888', fontSize: 12 }}>{index + 1}</td>
                <td className="monospace" data-label="编号">{d.part_no}</td>
                <td data-label="名称">{d.name}</td>
                <td data-label="规格">{d.spec}</td>
                <td
                  className={d.stock < d.safety_stock ? 'status-error' : ''}
                  data-label="库存"
                  style={{ cursor: 'pointer', minWidth: 70 }}
                >
                  {inlineEditId === d.id ? (
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                      <input
                        ref={inlineInputRef}
                        type="number"
                        value={inlineStockVal}
                        onChange={e => setInlineStockVal(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter') commitInlineEdit(d);
                          if (e.key === 'Escape') setInlineEditId(null);
                        }}
                        onBlur={() => commitInlineEdit(d)}
                        style={{ width: 60, padding: '2px 6px', fontSize: 12,
                          border: '1px solid #1677ff', borderRadius: 4, outline: 'none' }}
                      />
                      <span style={{ fontSize: 11, color: '#888' }}>{d.unit}</span>
                    </span>
                  ) : (
                    <span onClick={() => startInlineEdit(d)} title="点击修改库存"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: 4, cursor: 'pointer' }}>
                      {d.stock} {d.unit}
                      <span style={{ fontSize: 10, color: '#bbb' }}>✏</span>
                    </span>
                  )}
                </td>
                <td data-label="安全库存">{d.safety_stock}</td>
                <td data-label="位置">{d.storage_location}</td>
                <td data-label="品牌">{d.brand}</td>
                <td style={{ whiteSpace: 'nowrap', padding: '10px 12px' }}>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <button className="btn-action btn-usage" onClick={() => openUsage(d)}>领用</button>
                    <button className="btn-action btn-stockin" onClick={() => openStockin(d)}>入库</button>
                    <button className="btn-action btn-edit" onClick={() => { setEditItem(d); setShowForm(true); }}>编辑</button>
                    <button className="btn-action btn-delete" onClick={() => setConfirmDelete(d)}>删除</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ===== 新增/编辑弹窗 ===== */}
      {showForm && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>{editItem ? '编辑备件' : '新增备件'}</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-grid">
                <div><label>备件编号</label><input name="part_no" value={editItem ? (formData.part_no || '') : nextNo} onChange={handleInputChange} readOnly={!editItem} style={!editItem ? { backgroundColor: 'var(--bg-secondary, #f5f5f5)', color: 'var(--text-secondary)' } : {}} /></div>
                <div><label>备件名称 *</label><input name="name" value={formData.name || ''} onChange={handleInputChange} required /></div>
                <div><label>规格型号 *</label><input name="spec" value={formData.spec || ''} onChange={handleInputChange} required /></div>
                <div><label>存放位置 *</label><input name="storage_location" value={formData.storage_location || ''} onChange={handleInputChange} required /></div>
                <div><label>当前库存 *</label><input name="stock" type="number" value={formData.stock ?? 0} onChange={handleInputChange} required /></div>
                <div><label>安全库存 *</label><input name="safety_stock" type="number" value={formData.safety_stock ?? 5} onChange={handleInputChange} required /></div>
                <div><label>品牌</label><input name="brand" value={formData.brand || ''} onChange={handleInputChange} /></div>
                <div><label>单位</label><input name="unit" value={formData.unit || '个'} onChange={handleInputChange} /></div>
                <div><label>单价</label><input name="unit_price" type="number" value={formData.unit_price ?? ''} onChange={handleInputChange} /></div>
                <div><label>供应商</label><input name="supplier" value={formData.supplier || ''} onChange={handleInputChange} /></div>
                <div><label>适用设备</label><input name="applicable_devices" value={formData.applicable_devices || ''} onChange={handleInputChange} /></div>
                <div><label>采购周期(天)</label><input name="purchase_cycle_days" type="number" value={formData.purchase_cycle_days ?? ''} onChange={handleInputChange} /></div>
                <div style={{ gridColumn: '1/-1' }}><label>备注</label><input name="remarks" value={formData.remarks || ''} onChange={handleInputChange} /></div>
              </div>
              <div className="form-actions">
                <button type="button" onClick={() => { setShowForm(false); setEditItem(null); }}>取消</button>
                <button type="submit" className="primary" disabled={submitting}>
                  {submitting ? '保存中...' : '保存'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
