import { useState, useEffect, useMemo } from 'react';
import { repairApi, statsApi, maintenanceApi } from '../services/api';

const LINE_OPTIONS = ['全部', '1线', '2线', '3线', '4线', 'VIP线', '紫外', '紫外车间', '工艺', '工艺组', '设备', '设备组'];
const YEAR_OPTIONS = ['全部', '2024', '2025', '2026'];

export default function StatsDashboard() {
  const [overview, setOverview] = useState<any>(null);
  const [summary, setSummary] = useState<any[]>([]);
  const [monthlyTrend, setMonthlyTrend] = useState<any[]>([]);
  const [byLineData, setByLineData] = useState<any[]>([]);
  const [faultFreq, setFaultFreq] = useState<any[]>([]);
  const [faultTypes, setFaultTypes] = useState<any[]>([]);
  const [lowStock, setLowStock] = useState<any[]>([]);
  const [maintenanceList, setMaintenanceList] = useState<any[]>([]);
  const [yearFilter, setYearFilter] = useState('2026');
  const [lineFilter, setLineFilter] = useState('全部');

  const fetchParams = useMemo(() => {
    const p: Record<string, string> = {};
    if (yearFilter !== '全部') p.year = yearFilter;
    if (lineFilter !== '全部') p.line = lineFilter;
    return p;
  }, [yearFilter, lineFilter]);

  useEffect(() => {
    statsApi.overview().then(r => setOverview(r.data));
    statsApi.faultFrequency().then(r => setFaultFreq(r.data));
    statsApi.faultTypes().then(r => setFaultTypes(r.data));
    statsApi.lowStock().then(r => setLowStock(r.data));
    maintenanceApi.list().then((r: any) => setMaintenanceList(r.data || r || [])).catch(console.error);
  }, []);

  useEffect(() => {
    repairApi.statsMonthlyTrend(fetchParams).then((r: any) => setMonthlyTrend(r.data || r || [])).catch(console.error);
    repairApi.statsByLine(fetchParams).then((r: any) => setByLineData(r.data || r || [])).catch(console.error);
    repairApi.statsSummary(fetchParams).then((r: any) => setSummary(r.data || r || [])).catch(console.error);
  }, [fetchParams]);

  // 汇总数据：设备维修 & 工具维修
  const deviceSummary = useMemo(() => summary.find((s: any) => s.work_order_type === '设备维修') || { total: 0, completed: 0, completionRate: 0 }, [summary]);
  const toolSummary = useMemo(() => summary.find((s: any) => s.work_order_type === '工具维修') || { total: 0, completed: 0, completionRate: 0 }, [summary]);

  // 月度趋势按月份分组
  const trendByMonth = useMemo(() => {
    const map: Record<string, { device: any; tool: any }> = {};
    for (const row of monthlyTrend) {
      if (!map[row.month]) map[row.month] = { device: null, tool: null };
      if (row.work_order_type === '设备维修') map[row.month].device = row;
      else if (row.work_order_type === '工具维修') map[row.month].tool = row;
    }
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b));
  }, [monthlyTrend]);

  const trendMax = useMemo(() => {
    if (!trendByMonth.length) return 10;
    let max = 0;
    for (const [, data] of trendByMonth) {
      max = Math.max(max, data.device?.total || 0, data.tool?.total || 0);
    }
    return Math.ceil(max * 1.2) || 10;
  }, [trendByMonth]);

  // 线体统计表格 - 按线体+类型合并展示
  const tableRows = useMemo(() => {
    const lineSet = new Set<string>();
    for (const r of byLineData) if (r.line) lineSet.add(r.line);
    const lines = Array.from(lineSet).sort((a, b) => a.localeCompare(b, 'zh'));

    const rows: any[] = [];
    for (const line of lines) {
      const dr = byLineData.find((r: any) => r.line === line && r.work_order_type === '设备维修');
      const tr = byLineData.find((r: any) => r.line === line && r.work_order_type === '工具维修');
      rows.push({
        line,
        deviceTotal: dr?.total || 0,
        deviceCompleted: dr?.completed || 0,
        deviceRate: dr?.completionRate || 0,
        toolTotal: tr?.total || 0,
        toolCompleted: tr?.completed || 0,
        toolRate: tr?.completionRate || 0,
      });
    }
    return rows;
  }, [byLineData]);

  // 合计行
  const totals = useMemo(() => {
    let dT = 0, dC = 0, tT = 0, tC = 0;
    for (const r of tableRows) { dT += r.deviceTotal; dC += r.deviceCompleted; tT += r.toolTotal; tC += r.toolCompleted; }
    return {
      deviceTotal: dT, deviceCompleted: dC,
      deviceRate: dT > 0 ? Math.round(dC / dT * 1000) / 10 : 0,
      toolTotal: tT, toolCompleted: tC,
      toolRate: tT > 0 ? Math.round(tC / tT * 1000) / 10 : 0,
    };
  }, [tableRows]);

  const rateColor = (rate: number) => rate < 60 ? '#ff4d4f' : '#52c41a';

  return (
    <div>
      {/* 筛选器 */}
      <div style={{ marginBottom: 16, display: 'flex', gap: 8, alignItems: 'center' }}>
        <select value={yearFilter} onChange={e => setYearFilter(e.target.value)}
          style={{ padding: '3px 8px', borderRadius: 4, border: '1px solid var(--border)', background: 'var(--card-bg, #1a1a2e)', color: 'var(--text, #e0e0e0)', fontSize: 13 }}>
          {YEAR_OPTIONS.map(y => <option key={y} value={y}>{y === '全部' ? '全部年份' : y + '年'}</option>)}
        </select>
        <select value={lineFilter} onChange={e => setLineFilter(e.target.value)}
          style={{ padding: '3px 8px', borderRadius: 4, border: '1px solid var(--border)', background: 'var(--card-bg, #1a1a2e)', color: 'var(--text, #e0e0e0)', fontSize: 13 }}>
          {LINE_OPTIONS.map(l => <option key={l} value={l}>{l === '全部' ? '全部线体' : l}</option>)}
        </select>
      </div>

      {/* 统计卡片 */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16, marginBottom: 24 }}>
        <div className="card" style={{ padding: 20, textAlign: 'center' }}>
          <div style={{ fontSize: 14, color: '#888', marginBottom: 8 }}>设备维修总工单</div>
          <div style={{ fontSize: 36, fontWeight: 'bold', color: 'var(--accent-cyan, #00d4ff)' }}>{deviceSummary.total}</div>
          <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>
            完成 <span style={{ color: '#52c41a' }}>{deviceSummary.completed}</span> 件
          </div>
        </div>
        <div className="card" style={{ padding: 20, textAlign: 'center' }}>
          <div style={{ fontSize: 14, color: '#888', marginBottom: 8 }}>设备维修完成率</div>
          <div style={{ fontSize: 36, fontWeight: 'bold', color: rateColor(deviceSummary.completionRate) }}>{deviceSummary.completionRate}%</div>
        </div>
        <div className="card" style={{ padding: 20, textAlign: 'center' }}>
          <div style={{ fontSize: 14, color: '#888', marginBottom: 8 }}>工具维修总工单</div>
          <div style={{ fontSize: 36, fontWeight: 'bold', color: '#faad14' }}>{toolSummary.total}</div>
          <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>
            完成 <span style={{ color: '#52c41a' }}>{toolSummary.completed}</span> 件
          </div>
        </div>
        <div className="card" style={{ padding: 20, textAlign: 'center' }}>
          <div style={{ fontSize: 14, color: '#888', marginBottom: 8 }}>工具维修完成率</div>
          <div style={{ fontSize: 36, fontWeight: 'bold', color: rateColor(toolSummary.completionRate) }}>{toolSummary.completionRate}%</div>
        </div>
      </div>

      {/* 设备总览 */}
      <div className="stat-grid" style={{ marginBottom: 24 }}>
        <div className="stat-card"><div className="label">设备总数</div><div className="value">{overview?.deviceCount ?? '-'}</div></div>
        <div className="stat-card"><div className="label">待处理工单</div><div className="value" style={{ color: 'orange' }}>{overview?.repairCount ?? '-'}</div></div>
        <div className="stat-card"><div className="label">备件种类</div><div className="value">{overview?.partCount ?? '-'}</div></div>
        <div className="stat-card"><div className="label">低库存预警</div><div className="value" style={{ color: 'red' }}>{overview?.lowStockCount ?? '-'}</div></div>
      </div>

      {/* 月度趋势图 */}
      {trendByMonth.length > 0 && (
        <div className="card" style={{ padding: 20, marginBottom: 16 }}>
          <h3 style={{ marginTop: 0, marginBottom: 16 }}>设备维修 vs 工具维修 月度趋势</h3>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, height: 220, borderBottom: '1px solid var(--border)', borderLeft: '1px solid var(--border)', paddingLeft: 40, position: 'relative' }}>
            {/* Y轴刻度 */}
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 36, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', fontSize: 12, color: '#888' }}>
              <span>{trendMax}</span>
              <span>{Math.round(trendMax / 2)}</span>
              <span>0</span>
            </div>
            {trendByMonth.map(([month, data], i) => {
              const dv = data.device?.total || 0;
              const tv = data.tool?.total || 0;
              return (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', justifyContent: 'flex-end' }}>
                  <div style={{ width: '100%', display: 'flex', gap: 2, justifyContent: 'center', alignItems: 'flex-end', height: '100%' }}>
                    {/* 设备维修柱 */}
                    <div title={`设备维修: ${dv}单`} style={{ width: 16, minHeight: dv > 0 ? 4 : 0, height: `${(dv / trendMax) * 100}%`, backgroundColor: 'var(--accent-cyan, #00d4ff)', borderRadius: '3px 3px 0 0', transition: 'height 0.3s' }}>
                      {dv > 0 && <div style={{ fontSize: 11, color: '#fff', textAlign: 'center', lineHeight: '16px', whiteSpace: 'nowrap' }}>{dv}</div>}
                    </div>
                    {/* 工具维修柱 */}
                    <div title={`工具维修: ${tv}单`} style={{ width: 16, minHeight: tv > 0 ? 4 : 0, height: `${(tv / trendMax) * 100}%`, backgroundColor: '#faad14', borderRadius: '3px 3px 0 0', transition: 'height 0.3s' }}>
                      {tv > 0 && <div style={{ fontSize: 11, color: '#fff', textAlign: 'center', lineHeight: '16px', whiteSpace: 'nowrap' }}>{tv}</div>}
                    </div>
                  </div>
                  <div style={{ fontSize: 12, color: '#888', marginTop: 6, whiteSpace: 'nowrap' }}>{month}</div>
                </div>
              );
            })}
          </div>
          <div style={{ display: 'flex', gap: 24, marginTop: 10, fontSize: 13, color: '#aaa' }}>
            <span><span style={{ display: 'inline-block', width: 14, height: 14, backgroundColor: 'var(--accent-cyan, #00d4ff)', borderRadius: 3, marginRight: 6, verticalAlign: 'middle' }} />设备维修</span>
            <span><span style={{ display: 'inline-block', width: 14, height: 14, backgroundColor: '#faad14', borderRadius: 3, marginRight: 6, verticalAlign: 'middle' }} />工具维修</span>
          </div>
        </div>
      )}

      {/* 线体维修统计表格 */}
      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginTop: 0, marginBottom: 16 }}>线体维修统计明细</h3>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid var(--border)' }}>
                <th style={{ padding: '10px 12px', textAlign: 'left' }}>线体</th>
                <th style={{ padding: '10px 12px', textAlign: 'center' }}>设备工单数</th>
                <th style={{ padding: '10px 12px', textAlign: 'center' }}>设备完成率</th>
                <th style={{ padding: '10px 12px', textAlign: 'center' }}>工具工单数</th>
                <th style={{ padding: '10px 12px', textAlign: 'center' }}>工具完成率</th>
              </tr>
            </thead>
            <tbody>
              {tableRows.length === 0 && (
                <tr><td colSpan={5} style={{ padding: 24, textAlign: 'center', color: '#888' }}>暂无数据</td></tr>
              )}
              {tableRows.map((r, i) => (
                <tr key={i} style={{ borderBottom: '1px solid var(--border, rgba(255,255,255,0.06))' }}>
                  <td style={{ padding: '10px 12px', fontWeight: 500 }}>{r.line}</td>
                  <td style={{ padding: '10px 12px', textAlign: 'center' }}>{r.deviceTotal}</td>
                  <td style={{ padding: '10px 12px', textAlign: 'center', color: rateColor(r.deviceRate), fontWeight: r.deviceRate < 60 ? 700 : 400 }}>{r.deviceRate}%</td>
                  <td style={{ padding: '10px 12px', textAlign: 'center' }}>{r.toolTotal}</td>
                  <td style={{ padding: '10px 12px', textAlign: 'center', color: rateColor(r.toolRate), fontWeight: r.toolRate < 60 ? 700 : 400 }}>{r.toolRate}%</td>
                </tr>
              ))}
            </tbody>
            {tableRows.length > 0 && (
              <tfoot>
                <tr style={{ borderTop: '2px solid var(--accent-cyan, #00d4ff)', fontWeight: 700 }}>
                  <td style={{ padding: '12px', fontWeight: 700 }}>合计</td>
                  <td style={{ padding: '12px', textAlign: 'center' }}>{totals.deviceTotal}</td>
                  <td style={{ padding: '12px', textAlign: 'center', color: rateColor(totals.deviceRate) }}>{totals.deviceRate}%</td>
                  <td style={{ padding: '12px', textAlign: 'center' }}>{totals.toolTotal}</td>
                  <td style={{ padding: '12px', textAlign: 'center', color: rateColor(totals.toolRate) }}>{totals.toolRate}%</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* 故障频率 TOP20 */}
      <div className="card" style={{ marginBottom: 16 }}>
        <h3>故障频率 TOP20（近90天）</h3>
        <table>
          <thead><tr><th>设备编号</th><th>设备名称</th><th>故障次数</th><th>平均维修(分钟)</th></tr></thead>
          <tbody>
            {faultFreq.map((d: any, i: number) => <tr key={i}>
              <td>{d.deviceNo}</td><td>{d.deviceName}</td>
              <td>{d.faultCount}</td><td>{d.avgDuration ?? '-'}</td>
            </tr>)}
          </tbody>
        </table>
      </div>

      {/* 故障类型分布 */}
      <div className="card" style={{ marginBottom: 16 }}>
        <h3>故障类型分布（近90天）</h3>
        <table>
          <thead><tr><th>故障类型</th><th>次数</th></tr></thead>
          <tbody>
            {faultTypes.map((d: any, i: number) => <tr key={i}>
              <td>{d.name}</td><td>{d.value}</td>
            </tr>)}
          </tbody>
        </table>
      </div>

      {/* 低库存预警 */}
      {lowStock.length > 0 && (
        <div className="card" style={{ border: '2px solid red' }}>
          <h3 style={{ color: 'red' }}>低库存预警</h3>
          <table>
            <thead><tr><th>备件编号</th><th>名称</th><th>当前库存</th><th>安全库存</th><th>位置</th></tr></thead>
            <tbody>
              {lowStock.map((d: any) => <tr key={d.id}>
                <td>{d.part_no}</td><td>{d.name}</td>
                <td style={{ color: 'red', fontWeight: 700 }}>{d.stock}</td>
                <td>{d.safety_stock}</td><td>{d.storage_location}</td>
              </tr>)}
            </tbody>
          </table>
        </div>
      )}

      {/* 保养计划看板 */}
      {maintenanceList.length > 0 && (() => {
        const pending = maintenanceList.filter((d: any) => d.status === '待执行');
        const ongoing = maintenanceList.filter((d: any) => d.status === '执行中');
        const activeItems = [...pending, ...ongoing];
        if (activeItems.length === 0) return null;
        return (
          <div className="card" style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3 style={{ margin: 0 }}>保养计划看板</h3>
              <span style={{ fontSize: 13, color: '#888' }}>
                待执行 <span style={{ color: 'var(--accent-cyan, #00d4ff)', fontWeight: 700 }}>{pending.length}</span>
                {' / '}
                执行中 <span style={{ color: '#faad14', fontWeight: 700 }}>{ongoing.length}</span>
              </span>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ borderBottom: '2px solid var(--border)' }}>
                    <th style={{ padding: '10px 12px', textAlign: 'left' }}>计划编号</th>
                    <th style={{ padding: '10px 12px', textAlign: 'left' }}>保养位置</th>
                    <th style={{ padding: '10px 12px', textAlign: 'left' }}>保养内容</th>
                    <th style={{ padding: '10px 12px', textAlign: 'left' }}>计划日期</th>
                    <th style={{ padding: '10px 12px', textAlign: 'left' }}>负责人</th>
                    <th style={{ padding: '10px 12px', textAlign: 'center' }}>状态</th>
                  </tr>
                </thead>
                <tbody>
                  {activeItems.map((d: any) => (
                    <tr key={d.id} style={{ borderBottom: '1px solid var(--border, rgba(255,255,255,0.06))' }}>
                      <td style={{ padding: '10px 12px' }} className="monospace">{d.plan_no}</td>
                      <td style={{ padding: '10px 12px', fontWeight: 500 }}>{d.maintenance_type}</td>
                      <td style={{ padding: '10px 12px', maxWidth: 400 }}>{d.task_desc}</td>
                      <td style={{ padding: '10px 12px' }}>{d.plan_date}</td>
                      <td style={{ padding: '10px 12px' }}>{d.responsible_person}</td>
                      <td style={{ padding: '10px 12px', textAlign: 'center' }}>
                        <span style={{
                          display: 'inline-block', padding: '2px 10px', borderRadius: 12, fontSize: 12, fontWeight: 600,
                          backgroundColor: d.status === '执行中' ? '#faad1422' : 'var(--accent-cyan, #00d4ff)15',
                          color: d.status === '执行中' ? '#faad14' : 'var(--accent-cyan, #00d4ff)',
                          border: `1px solid ${d.status === '执行中' ? '#faad1455' : 'var(--accent-cyan, #00d4ff)33'}`,
                        }}>{d.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
