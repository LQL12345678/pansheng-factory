import { useState } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import DeviceList from './pages/DeviceList';
import RepairList from './pages/RepairList';
import PartList from './pages/PartList';
import MaintenancePlan from './pages/MaintenancePlan';
import ToolList from './pages/ToolList';
import StatsDashboard from './pages/StatsDashboard';
import HomePage from './pages/HomePage';

const navs = [
  ['/', '首页', '🏠'],
  ['/devices', '设备台账', '📋'],
  ['/tools', '工具台账', '🛠️'],
  ['/parts', '零部件库存', '🧩'],
  ['/repairs', '故障维修', '🔧'],
  ['/maintenance', '保养计划', '📅'],
  ['/stats', '统计看板', '📊'],
];

export default function App() {
  const { pathname } = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const isActive = (path: string) => {
    if (path === '/') return pathname === '/';
    return pathname.startsWith(path);
  };

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
  const closeSidebar = () => setSidebarOpen(false);

  return (
    <div className="app-layout">
      {/* 顶部栏 */}
      <header className="topbar">
        <div className="topbar-left">
          <button className="menu-toggle" onClick={toggleSidebar}>
            <span className="menu-icon">☰</span>
          </button>
          <h1 className="logo">⚙️ 攀升工厂设备管理系统</h1>
        </div>
        <div className="topbar-right" />
      </header>

      <div className="app-body">
        {/* 侧边栏遮罩 */}
        {sidebarOpen && <div className="sidebar-overlay" onClick={closeSidebar} />}

        {/* 侧边栏 */}
        <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
          <div className="sidebar-header">
            <span>导航菜单</span>
            <button className="sidebar-close" onClick={closeSidebar}>✕</button>
          </div>
          <nav className="sidebar-nav">
            {navs.map(([p, l, icon]) => (
              <Link
                key={p}
                to={p}
                className={`nav-item ${isActive(p) ? 'active' : ''}`}
                onClick={closeSidebar}
              >
                <span className="nav-icon">{icon}</span>
                <span className="nav-label">{l}</span>
              </Link>
            ))}
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/devices/*" element={<DeviceList />} />
            <Route path="/repairs/*" element={<RepairList />} />
            <Route path="/tools/*" element={<ToolList />} />
            <Route path="/parts/*" element={<PartList />} />
            <Route path="/maintenance/*" element={<MaintenancePlan />} />
            <Route path="/stats" element={<StatsDashboard />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
