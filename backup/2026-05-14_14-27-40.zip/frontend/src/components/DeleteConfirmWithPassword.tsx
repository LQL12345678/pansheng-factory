import { useState, useEffect, useRef } from 'react';

const DELETE_PASSWORD = '8520';

interface DeleteConfirmProps {
  visible: boolean;
  title?: string;
  message?: string;
  itemName?: string;
  onConfirm: () => void;
  onCancel: () => void;
  loading?: boolean;
}

export default function DeleteConfirmWithPassword({
  visible,
  title = '确认删除',
  message,
  itemName,
  onConfirm,
  onCancel,
  loading = false,
}: DeleteConfirmProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (visible) {
      setPassword('');
      setError(false);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [visible]);

  if (!visible) return null;

  const handleConfirm = () => {
    if (password === DELETE_PASSWORD) {
      onConfirm();
    } else {
      setError(true);
      setPassword('');
      inputRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleConfirm();
    if (e.key === 'Escape') onCancel();
  };

  return (
    <div className="modal-overlay">
      <div className="modal" style={{ maxWidth: 380, textAlign: 'center' }}>
        <h3 style={{ marginBottom: 12 }}>{title}</h3>
        {message && (
          <p style={{ color: 'var(--text-secondary)', marginBottom: 16, fontSize: 14 }}>
            {message}
          </p>
        )}
        {itemName && (
          <p style={{ marginBottom: 16, fontSize: 14 }}>
            确定删除 <strong style={{ color: '#ff4d4f' }}>「{itemName}」</strong> 吗？此操作不可恢复。
          </p>
        )}
        {!itemName && !message && (
          <p style={{ color: 'var(--text-secondary)', marginBottom: 16, fontSize: 14 }}>
            确定要删除吗？此操作不可撤销。
          </p>
        )}
        <div style={{ marginBottom: 20 }}>
          <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6, textAlign: 'left' }}>
            请输入管理密码以确认删除
          </label>
          <input
            ref={inputRef}
            type="password"
            value={password}
            onChange={e => { setPassword(e.target.value); setError(false); }}
            onKeyDown={handleKeyDown}
            placeholder="输入密码"
            style={{
              width: '100%',
              padding: '8px 12px',
              borderRadius: 6,
              border: error ? '1px solid #ff4d4f' : '1px solid var(--border)',
              fontSize: 16,
              textAlign: 'center',
              letterSpacing: 8,
              outline: 'none',
              backgroundColor: 'var(--bg-card)',
              color: 'var(--text)',
              boxSizing: 'border-box',
            }}
            autoFocus
          />
          {error && (
            <div style={{ color: '#ff4d4f', fontSize: 12, marginTop: 6 }}>密码错误，请重新输入</div>
          )}
        </div>
        <div className="form-actions" style={{ justifyContent: 'center' }}>
          <button type="button" onClick={onCancel}>取消</button>
          <button
            type="button"
            className="danger"
            onClick={handleConfirm}
            disabled={loading || !password.trim()}
          >
            {loading ? '删除中...' : '确认删除'}
          </button>
        </div>
      </div>
    </div>
  );
}
