@echo off
cd /d C:\Users\Admin\WorkBuddy\2026-05-10-task-1\backend
start /b node server.js > nul 2>&1

timeout /t 2 /nobreak > nul

cd /d C:\Users\Admin\WorkBuddy\2026-05-10-task-1\frontend
npm run dev
