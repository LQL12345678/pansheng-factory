import { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import DeviceList from './pages/DeviceList';
import RepairList from './pages/RepairList';
import PartList from './pages/PartList';
import MaintenancePlan from './pages/MaintenancePlan';
import ToolList from './pages/ToolList';
import StatsDashboard from './pages/StatsDashboard';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import UserManagement from './pages/UserManagement';
import NotificationSettings from './pages/NotificationSettings';
import { useAuth } from './hooks/useAuth';

const navs: [string, string, string][] = [
  ['/', '首页', '🏠'],
  ['/devices', '设备台账', '📋'],
  ['/tools', '工具台账', '🛠️'],
  ['/parts', '库存管理', '🧩'],
  ['/repairs', '维修记录', '🔧'],
  ['/maintenance', '保养计划', '📅'],
  ['/stats', '数据看板', '📊'],
];

// 移动端Tab导航配置
const mobileTabs: [string, string, string][] = [
  ['/', '首页', '🏠'],
  ['/repairs', '工单', '📋'],
  ['/parts', '物品', '🧩'],
  ['/my', '我的', '👤'],
];

// ===== 网络状态提示组件 =====
function NetworkStatusBanner({ isConnected }: { isConnected: boolean }) {
  if (isConnected) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      background: 'linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%)',
      color: '#fff',
      padding: '12px 20px',
      textAlign: 'center',
      fontSize: '14px',
      zIndex: 9999,
      boxShadow: '0 2px 10px rgba(255, 71, 87, 0.4)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '10px',
    }}>
      <span style={{ fontSize: '18px' }}>📡</span>
      <span>服务器连接已断开，请检查网络或确保电脑处于开机状态</span>
      <button
        onClick={() => window.location.reload()}
        style={{
          background: 'rgba(255,255,255,0.2)',
          border: '1px solid rgba(255,255,255,0.3)',
          color: '#fff',
          padding: '4px 12px',
          borderRadius: '6px',
          cursor: 'pointer',
          fontSize: '12px',
          marginLeft: '10px',
        }}
      >
        重试
      </button>
    </div>
  );
}

export default function App() {
  const { pathname } = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const { user, isSuperAdmin, logout, checkAuth, isConnected } = useAuth();

  // 页面加载时验证会话
  useEffect(() => {
    checkAuth();
  }, []);

  // 监听窗口大小变化
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const isActive = (path: string) => {
    if (path === '/') return pathname === '/';
    if (path === '/my') {
      // 我的页面：用户管理或设置页面
      return pathname.startsWith('/users');
    }
    return pathname.startsWith(path);
  };

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
  const closeSidebar = () => setSidebarOpen(false);

  // 判断是否需要显示登录页（未登录且不在登录页）
  const showLogin = !user && pathname !== '/login';

  // 未登录时显示登录页
  if (showLogin) {
    return (
      <>
        <NetworkStatusBanner isConnected={isConnected} />
        <LoginPage />
      </>
    );
  }

  // 登录页不再需要（已登录用户访问登录页自动跳转）
  if (pathname === '/login') {
    window.location.href = '/';
    return null;
  }

  return (
    <>
      {/* 网络状态提示 */}
      <NetworkStatusBanner isConnected={isConnected} />
      <div className="app-layout" style={{ paddingTop: isConnected ? 0 : '44px' }}>
      {/* 顶部栏 */}
      <header className="topbar">
        <div className="topbar-left">
          <button className="menu-toggle" onClick={toggleSidebar}>
            <span className="menu-icon">☰</span>
          </button>
          <h1 className="logo">⚙️ 攀升工厂设备管理系统</h1>
        </div>
        <div className="topbar-right">
          {/* 用户信息 */}
          <div className="user-info">
            <span className="user-name">{user?.username}</span>
            <span className={`role-tag ${user?.role}`}>
              {user?.roleName}
            </span>
          </div>
          {/* 用户管理入口（仅超级管理员可见） */}
          {isSuperAdmin && (
            <>
              <Link to="/notifications" className="user-manage-btn">
                📱 通知设置
              </Link>
              <Link to="/users" className="user-manage-btn">
                👥 用户管理
              </Link>
            </>
          )}
          {/* 退出按钮 */}
          <button className="logout-btn" onClick={logout}>
            🚪 退出
          </button>
        </div>
      </header>

      <div className="app-body">
        {/* 侧边栏遮罩 */}
        {sidebarOpen && <div className="sidebar-overlay" onClick={closeSidebar} />}

        {/* 侧边栏 */}
        <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
          <div className="sidebar-header">
            <span>导航菜单</span>
            <button className="sidebar-close" onClick={closeSidebar}>✕</button>
          </div>
          <nav className="sidebar-nav">
            {navs.map(([p, l, icon]) => (
              <Link
                key={p}
                to={p}
                className={`nav-item ${isActive(p as string) ? 'active' : ''}`}
                onClick={closeSidebar}
              >
                <span className="nav-icon">{icon}</span>
                <span className="nav-label">{l}</span>
              </Link>
            ))}
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/devices/*" element={<DeviceList />} />
            <Route path="/repairs/*" element={<RepairList />} />
            <Route path="/tools/*" element={<ToolList />} />
            <Route path="/parts/*" element={<PartList />} />
            <Route path="/maintenance/*" element={<MaintenancePlan />} />
            <Route path="/stats" element={<StatsDashboard />} />
            <Route path="/users" element={<UserManagement />} />
            <Route path="/notifications" element={<NotificationSettings />} />
          </Routes>
        </main>
      </div>

      {/* 移动端底部Tab导航 */}
      {isMobile && (
        <nav className="mobile-tab-nav">
          {mobileTabs.map(([path, label, icon]) => {
            // 我的页面映射到用户管理
            const targetPath = path === '/my' ? '/users' : path;
            return (
              <Link
                key={path}
                to={targetPath}
                className={`mobile-tab-item ${isActive(path) ? 'active' : ''}`}
              >
                <span className="mobile-tab-icon">{icon}</span>
                <span className="mobile-tab-label">{label}</span>
              </Link>
            );
          })}
        </nav>
      )}

      <style>{`
        .topbar-right {
          display: flex;
          align-items: center;
          gap: 16px;
        }
        .user-info {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 6px 12px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 8px;
        }
        .user-name {
          color: #fff;
          font-size: 14px;
          font-weight: 500;
        }
        .role-tag {
          font-size: 12px;
          padding: 2px 8px;
          border-radius: 10px;
          font-weight: 500;
        }
        .role-tag.super_admin {
          background: rgba(255, 215, 0, 0.2);
          color: #ffd700;
        }
        .role-tag.admin {
          background: rgba(79, 172, 254, 0.2);
          color: #4facfe;
        }
        .role-tag.user {
          background: rgba(255, 255, 255, 0.1);
          color: rgba(255, 255, 255, 0.7);
        }
        .user-manage-btn {
          color: rgba(255, 255, 255, 0.8);
          font-size: 14px;
          text-decoration: none;
          padding: 6px 12px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          transition: all 0.2s;
        }
        .user-manage-btn:hover {
          background: rgba(255, 255, 255, 0.15);
          color: #fff;
        }
        .logout-btn {
          background: rgba(255, 71, 87, 0.2);
          border: 1px solid rgba(255, 71, 87, 0.3);
          color: #ff6b7a;
          padding: 6px 14px;
          border-radius: 8px;
          font-size: 14px;
          cursor: pointer;
          transition: all 0.2s;
        }
        .logout-btn:hover {
          background: rgba(255, 71, 87, 0.3);
        }

        /* 移动端适配 */
        @media screen and (max-width: 768px) {
          .topbar h1.logo {
            font-size: 14px;
          }
          .user-info {
            display: none;
          }
          .user-manage-btn {
            display: none;
          }
          .logout-btn {
            padding: 6px 10px;
            font-size: 12px;
          }
          .logout-btn span {
            display: none;
          }
          .logout-btn::before {
            content: '🚪';
          }
        }
      `}</style>
      </div>
    </>
  );
}
