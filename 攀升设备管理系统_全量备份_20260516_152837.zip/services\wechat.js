/**
 * 企业微信 Webhook 通知服务
 */

const { db } = require('../db');

/**
 * 发送企业微信消息
 * @param {string} webhookUrl - Webhook URL
 * @param {object} message - 消息内容（Markdown 格式）
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function sendWechatMessage(webhookUrl, message) {
  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(message)
    });

    const result = await response.json();

    if (result.errcode === 0) {
      return { success: true };
    } else {
      return { success: false, error: result.errmsg || '发送失败' };
    }
  } catch (err) {
    return { success: false, error: err.message || '网络错误' };
  }
}

/**
 * 格式化工单消息（Markdown 格式）
 * @param {object} repair - 工单数据
 * @param {string} type - 消息类型：'immediate'(立即通知) / 'scheduled'(定时汇总)
 * @returns {object} 企业微信消息格式
 */
function formatRepairMessage(repair, type = 'immediate') {
  const title = type === 'immediate' ? '🔔 新工单报修通知' : '📋 待处理工单提醒';

  if (type === 'scheduled') {
    // 定时通知：汇总多条工单
    const pendingRepairs = Array.isArray(repair) ? repair : [repair];
    const count = pendingRepairs.length;

    let content = `### ${title}\n`;
    content += `> 当前有 **${count}** 条待处理工单，请及时处理\n\n`;

    pendingRepairs.slice(0, 5).forEach((r, i) => {
      content += `**${i + 1}. ${r.line || '未知线体'}-${r.area || r.device_name || '未知设备'}**\n`;
      content += `   - 工单号：${r.work_order_no || '无'}\n`;
      content += `   - 故障：${r.fault_desc || '无描述'}\n`;
      content += `   - 报修人：${r.reporter || '未知'}\n`;
      content += `   - 报修时间：${r.report_date || ''}\n\n`;
    });

    if (count > 5) {
      content += `> 还有 **${count - 5}** 条工单未显示...\n`;
    }

    return {
      msgtype: 'markdown',
      markdown: { content }
    };
  } else {
    // 立即通知：单条工单详情
    const content = `### ${title}\n\n` +
      `**工单号**：${repair.work_order_no || '无'}\n` +
      `**工单类型**：${repair.work_order_type || '设备维修'}\n` +
      `**线体**：${repair.line || '未知'}\n` +
      `**设备/区域**：${repair.area || repair.device_name || '未知'}\n` +
      `**故障描述**：${repair.fault_desc || '无描述'}\n` +
      `**报修人**：${repair.reporter || '未知'}\n` +
      `**报修时间**：${repair.report_date || ''} ${repair.report_time || ''}\n` +
      `**状态**：🔴 ${repair.status || '待处理'}\n`;

    return {
      msgtype: 'markdown',
      markdown: { content }
    };
  }
}

/**
 * 记录通知日志
 * @param {object} logData
 */
function logNotification(logData) {
  try {
    db.prepare(`
      INSERT INTO wechat_notification_logs
        (notification_type, target_user, title, content, related_id, repair_id, send_type, send_url, status, sent_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))
    `).run(
      logData.notification_type || 'repair',
      logData.target_user || 'webhook',
      logData.title || '',
      logData.content || '',
      logData.repair_id || null,
      logData.repair_id || null,
      logData.send_type || 'immediate',
      logData.webhook_url || '',
      logData.success ? 'sent' : 'failed',
    );
  } catch (err) {
    console.error('记录通知日志失败:', err.message);
  }
}

/**
 * 获取通知配置
 */
function getNotificationConfig() {
  const config = db.prepare('SELECT * FROM notification_config WHERE id = 1').get();
  if (config) {
    config.notify_admin_ids = JSON.parse(config.notify_admin_ids || '[]');
  }
  return config;
}

/**
 * 更新通知配置
 */
function updateNotificationConfig(data) {
  const config = getNotificationConfig();
  const updates = [];
  const params = [];

  if (data.webhook_url !== undefined) {
    updates.push('webhook_url = ?');
    params.push(data.webhook_url);
  }
  if (data.enabled !== undefined) {
    updates.push('enabled = ?');
    params.push(data.enabled ? 1 : 0);
  }
  if (data.notify_immediately !== undefined) {
    updates.push('notify_immediately = ?');
    params.push(data.notify_immediately ? 1 : 0);
  }
  if (data.notify_scheduled !== undefined) {
    updates.push('notify_scheduled = ?');
    params.push(data.notify_scheduled ? 1 : 0);
  }
  if (data.schedule_interval_minutes !== undefined) {
    updates.push('schedule_interval_minutes = ?');
    params.push(data.schedule_interval_minutes);
  }
  if (data.notify_admin_ids !== undefined) {
    updates.push('notify_admin_ids = ?');
    params.push(JSON.stringify(data.notify_admin_ids));
  }

  if (updates.length === 0) return config;

  updates.push("updated_at = datetime('now', 'localtime')");
  params.push(1);

  db.prepare(`UPDATE notification_config SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  return getNotificationConfig();
}

/**
 * 发送工单通知
 * @param {object} repair - 工单数据
 * @param {string} type - 'immediate' | 'scheduled'
 * @returns {Promise<{success: boolean, message: string}>}
 */
async function notifyRepair(repair, type = 'immediate') {
  const config = getNotificationConfig();

  if (!config || !config.enabled) {
    return { success: false, message: '通知未启用' };
  }

  if (!config.webhook_url) {
    return { success: false, message: '未配置 Webhook URL' };
  }

  const message = formatRepairMessage(repair, type);
  const result = await sendWechatMessage(config.webhook_url, message);

  // 记录日志
  logNotification({
    notification_type: 'repair',
    target_user: 'webhook',
    title: type === 'immediate' ? '新工单报修通知' : '待处理工单提醒',
    content: JSON.stringify(message),
    repair_id: repair.id,
    send_type: type,
    webhook_url: config.webhook_url,
    success: result.success
  });

  return {
    success: result.success,
    message: result.success ? '发送成功' : (result.error || '发送失败')
  };
}

/**
 * 发送测试通知
 */
async function sendTestNotification() {
  const config = getNotificationConfig();

  if (!config || !config.webhook_url) {
    return { success: false, message: '未配置 Webhook URL' };
  }

  const message = {
    msgtype: 'markdown',
    markdown: {
      content: `### ✅ 通知测试\n\n> 这是一条测试消息，用于验证企业微信 Webhook 配置是否正确。\n\n**发送时间**：${new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })}\n**系统**：攀升工厂设备管理系统`
    }
  };

  const result = await sendWechatMessage(config.webhook_url, message);

  logNotification({
    notification_type: 'test',
    target_user: 'webhook',
    title: '通知测试',
    content: JSON.stringify(message),
    send_type: 'test',
    webhook_url: config.webhook_url,
    success: result.success
  });

  return {
    success: result.success,
    message: result.success ? '测试消息发送成功' : (result.error || '发送失败')
  };
}

/**
 * 获取通知日志
 */
function getNotificationLogs(limit = 50) {
  return db.prepare(`
    SELECT * FROM wechat_notification_logs
    ORDER BY created_at DESC
    LIMIT ?
  `).all(limit);
}

/**
 * 格式化工单完结消息（Markdown 格式）
 * @param {object} repair - 工单数据
 * @returns {object} 企业微信消息格式
 */
function formatRepairCompletedMessage(repair) {
  // 使用本地时间格式
  const now = new Date();
  const localTime = now.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
  const finishTime = repair.finish_time || localTime;

  // 根据工单类型显示不同标题
  const isToolUsage = repair.work_order_type === '工具领用';
  const title = isToolUsage ? '### 🔧 备件领用通知' : '### ✅ 工单完结通知';
  const subtitle = isToolUsage ? '备件已成功领取' : '设备维修工单已完成处理';

  let content = `${title}\n\n> ${subtitle}\n\n`;
  content += `**工单号**：${repair.work_order_no || '无'}\n`;
  content += `**工单类型**：${repair.work_order_type || '设备维修'}\n`;

  // 工具领用工单显示更多信息
  if (isToolUsage) {
    content += `**领用线体**：${repair.area || repair.line || '未知'}\n`;
    content += `**故障描述**：${repair.fault_desc || '无'}\n`;
    content += `**操作人**：${repair.repairman || '未知'}\n`;
  } else {
    content += `**线体**：${repair.line || '未知'}\n`;
    content += `**设备/区域**：${repair.area || repair.device_name || '未知'}\n`;
    content += `**故障描述**：${repair.fault_desc || '无描述'}\n`;
    content += `**处理方案**：${repair.solution || '无'}\n`;
    content += `**维修人员**：${repair.repairman || '未知'}\n`;
    content += `**停线时长**：${repair.stop_duration_minutes ? repair.stop_duration_minutes + '分钟' : (repair.duration_minutes ? repair.duration_minutes + '分钟' : '未知')}\n`;
    content += `**报修人**：${repair.reporter || '未知'}\n`;
    content += `**报修时间**：${repair.report_date || ''} ${repair.report_time || ''}${repair.report_second ? ':' + repair.report_second : ''}\n`;
  }

  content += `**完结时间**：${finishTime}\n`;
  content += `**状态**：✅ 已完成`;

  return {
    msgtype: 'markdown',
    markdown: { content }
  };
}

/**
 * 发送工单完结通知
 * @param {object} repair - 工单数据
 * @returns {Promise<{success: boolean, message: string}>}
 */
async function notifyRepairCompleted(repair) {
  const config = getNotificationConfig();

  if (!config || !config.enabled) {
    return { success: false, message: '通知未启用' };
  }

  if (!config.webhook_url) {
    return { success: false, message: '未配置 Webhook URL' };
  }

  const message = formatRepairCompletedMessage(repair);
  const result = await sendWechatMessage(config.webhook_url, message);

  // 记录日志
  logNotification({
    notification_type: 'repair_completed',
    target_user: 'webhook',
    title: '工单完结通知',
    content: JSON.stringify(message),
    repair_id: repair.id,
    send_type: 'completed',
    webhook_url: config.webhook_url,
    success: result.success
  });

  return {
    success: result.success,
    message: result.success ? '发送成功' : (result.error || '发送失败')
  };
}

/**
 * 格式化工具领用审批通过消息（Markdown 格式）
 * @param {object} log - 领用记录
 * @param {object} part - 备件信息
 * @returns {object} 企业微信消息格式
 */
function formatToolWithdrawApprovedMessage(log, part) {
  const now = new Date();
  const localTime = now.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });

  let content = `### 🔧 领用审批通过\n\n`;
  content += `> 备件领用申请已通过审批\n\n`;
  content += `**物品**：${part.name || '未知'}\n`;
  content += `**备件编号**：${part.part_no || '未知'}\n`;
  content += `**领用数量**：${log.quantity || 0}\n`;
  content += `**领用线体**：${log.line || '未指定'}\n`;
  content += `**领用人**：${log.handler || '未知'}\n`;
  if (log.purpose) {
    content += `**用途**：${log.purpose}\n`;
  }
  if (log.remarks) {
    content += `**备注**：${log.remarks}\n`;
  }
  content += `**审批人**：${log.approver || '管理员'}\n`;
  content += `**审批时间**：${localTime}\n`;
  content += `**状态**：✅ 审批通过`;

  return {
    msgtype: 'markdown',
    markdown: { content }
  };
}

/**
 * 发送工具领用审批通过通知
 * @param {object} log - 领用记录
 * @param {object} part - 备件信息
 * @returns {Promise<{success: boolean, message: string}>}
 */
async function notifyToolWithdrawApproved(log, part) {
  const config = getNotificationConfig();

  if (!config || !config.enabled) {
    return { success: false, message: '通知未启用' };
  }

  if (!config.webhook_url) {
    return { success: false, message: '未配置 Webhook URL' };
  }

  const message = formatToolWithdrawApprovedMessage(log, part);
  const result = await sendWechatMessage(config.webhook_url, message);

  // 记录日志
  logNotification({
    notification_type: 'tool_withdraw_approved',
    target_user: 'webhook',
    title: '备件领用审批通过',
    content: JSON.stringify(message),
    send_type: 'approved',
    webhook_url: config.webhook_url,
    success: result.success
  });

  return {
    success: result.success,
    message: result.success ? '发送成功' : (result.error || '发送失败')
  };
}

/**
 * 格式化备件领用申请消息（Markdown 格式）
 * @param {object} log - 领用记录
 * @param {object} part - 备件信息
 * @returns {object} 企业微信消息格式
 */
function formatUsageRequestMessage(log, part) {
  const now = new Date();
  const localTime = now.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });

  let content = `### 📋 备件领用申请\n\n`;
  content += `> 有新的备件领用申请，请审批\n\n`;
  content += `**物品**：${part.name || '未知'}\n`;
  content += `**备件编号**：${part.part_no || '未知'}\n`;
  content += `**领用数量**：${log.quantity || 0}\n`;
  content += `**领用线体**：${log.line || '未指定'}\n`;
  content += `**领用人**：${log.handler || '未知'}\n`;
  if (log.purpose) {
    content += `**用途**：${log.purpose}\n`;
  }
  if (log.remarks) {
    content += `**备注**：${log.remarks}\n`;
  }
  content += `**申请时间**：${localTime}\n`;
  content += `**状态**：⏳ 待审批`;

  return {
    msgtype: 'markdown',
    markdown: { content }
  };
}

/**
 * 发送备件领用申请通知
 * @param {object} log - 领用记录
 * @param {object} part - 备件信息
 * @returns {Promise<{success: boolean, message: string}>}
 */
async function notifyUsageRequest(log, part) {
  const config = getNotificationConfig();

  if (!config || !config.enabled) {
    return { success: false, message: '通知未启用' };
  }

  if (!config.webhook_url) {
    return { success: false, message: '未配置 Webhook URL' };
  }

  const message = formatUsageRequestMessage(log, part);
  const result = await sendWechatMessage(config.webhook_url, message);

  // 记录日志
  logNotification({
    notification_type: 'usage_request',
    target_user: 'webhook',
    title: '备件领用申请',
    content: JSON.stringify(message),
    send_type: 'usage_request',
    webhook_url: config.webhook_url,
    success: result.success
  });

  return {
    success: result.success,
    message: result.success ? '发送成功' : (result.error || '发送失败')
  };
}

module.exports = {
  sendWechatMessage,
  formatRepairMessage,
  formatRepairCompletedMessage,
  formatToolWithdrawApprovedMessage,
  logNotification,
  getNotificationConfig,
  updateNotificationConfig,
  notifyRepair,
  notifyRepairCompleted,
  notifyToolWithdrawApproved,
  notifyUsageRequest,
  sendTestNotification,
  getNotificationLogs
};
