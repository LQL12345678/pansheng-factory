module.exports = {
  apps: [
    {
      name: 'device-backend',
      script: 'server.js',
      cwd: 'C:/Users/Admin/WorkBuddy/2026-05-10-task-1/backend',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'development'
      },
      error_file: 'C:/Users/Admin/WorkBuddy/2026-05-10-task-1/logs/backend-error.log',
      out_file: 'C:/Users/Admin/WorkBuddy/2026-05-10-task-1/logs/backend-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss'
    },
    {
      name: 'device-frontend',
      script: 'npm',
      args: '.cmd run dev',
      cwd: 'C:/Users/Admin/WorkBuddy/2026-05-10-task-1/frontend',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '300M',
      env: {
        NODE_ENV: 'development'
      },
      error_file: 'C:/Users/Admin/WorkBuddy/2026-05-10-task-1/logs/frontend-error.log',
      out_file: 'C:/Users/Admin/WorkBuddy/2026-05-10-task-1/logs/frontend-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss'
    }
  ]
};
