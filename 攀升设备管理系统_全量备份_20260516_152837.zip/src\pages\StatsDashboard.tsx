import { useState, useEffect, useMemo } from 'react';
import { repairApi, statsApi } from '../services/api';

const LINE_OPTIONS = ['全部', '1线', '2线', '3线', '4线', 'VIP线', '紫外', '紫外车间', '工艺', '工艺组', '设备', '设备组'];
const YEAR_OPTIONS = ['全部', '2024', '2025', '2026'];

export default function StatsDashboard() {
  const [overview, setOverview] = useState<any>(null);
  const [summary, setSummary] = useState<any[]>([]);
  const [monthlyTrend, setMonthlyTrend] = useState<any[]>([]);
  const [byLineData, setByLineData] = useState<any[]>([]);
  const [faultFreq, setFaultFreq] = useState<any[]>([]);
  const [lowStock, setLowStock] = useState<any[]>([]);
  const [stopDurationData, setStopDurationData] = useState<any[]>([]);
  const [faultRateData, setFaultRateData] = useState<any[]>([]);
  const [yearFilter, setYearFilter] = useState('2026');
  const [lineFilter, setLineFilter] = useState('全部');

  const fetchParams = useMemo(() => {
    const p: Record<string, string> = {};
    if (yearFilter !== '全部') p.year = yearFilter;
    if (lineFilter !== '全部') p.line = lineFilter;
    return p;
  }, [yearFilter, lineFilter]);

  useEffect(() => {
    statsApi.overview().then(r => setOverview(r.data));
    statsApi.faultFrequency().then(r => setFaultFreq(r.data));
    statsApi.lowStock().then(r => setLowStock(r.data));
    statsApi.stopDurationByMonth(fetchParams).then((r: any) => setStopDurationData(r.data || r || [])).catch(console.error);
    statsApi.faultRateByMonth(fetchParams).then((r: any) => setFaultRateData(r.data || r || [])).catch(console.error);
  }, []);

  useEffect(() => {
    repairApi.statsMonthlyTrend(fetchParams).then((r: any) => setMonthlyTrend(r.data || r || [])).catch(console.error);
    repairApi.statsByLine(fetchParams).then((r: any) => setByLineData(r.data || r || [])).catch(console.error);
    repairApi.statsSummary(fetchParams).then((r: any) => setSummary(r.data || r || [])).catch(console.error);
  }, [fetchParams]);

  // 汇总数据：设备维修 & 工具维修
  const deviceSummary = useMemo(() => summary.find((s: any) => s.work_order_type === '设备维修') || { total: 0, completed: 0, completionRate: 0 }, [summary]);
  const toolSummary = useMemo(() => summary.find((s: any) => s.work_order_type === '工具维修') || { total: 0, completed: 0, completionRate: 0 }, [summary]);

  // 月度趋势按月份分组
  const trendByMonth = useMemo(() => {
    const map: Record<string, { device: any; tool: any }> = {};
    for (const row of monthlyTrend) {
      if (!map[row.month]) map[row.month] = { device: null, tool: null };
      if (row.work_order_type === '设备维修') map[row.month].device = row;
      else if (row.work_order_type === '工具维修') map[row.month].tool = row;
    }
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b));
  }, [monthlyTrend]);

  const trendMax = useMemo(() => {
    if (!trendByMonth.length) return 10;
    let max = 0;
    for (const [, data] of trendByMonth) {
      max = Math.max(max, data.device?.total || 0, data.tool?.total || 0);
    }
    return Math.ceil(max * 1.2) || 10;
  }, [trendByMonth]);

  // 线体统计表格 - 按线体+类型合并展示
  const tableRows = useMemo(() => {
    const lineSet = new Set<string>();
    for (const r of byLineData) if (r.line) lineSet.add(r.line);
    const lines = Array.from(lineSet).sort((a, b) => a.localeCompare(b, 'zh'));

    const rows: any[] = [];
    for (const line of lines) {
      const dr = byLineData.find((r: any) => r.line === line && r.work_order_type === '设备维修');
      const tr = byLineData.find((r: any) => r.line === line && r.work_order_type === '工具维修');
      rows.push({
        line,
        deviceTotal: dr?.total || 0,
        deviceCompleted: dr?.completed || 0,
        deviceRate: dr?.completionRate || 0,
        toolTotal: tr?.total || 0,
        toolCompleted: tr?.completed || 0,
        toolRate: tr?.completionRate || 0,
      });
    }
    return rows;
  }, [byLineData]);

  // 合计行
  const totals = useMemo(() => {
    let dT = 0, dC = 0, tT = 0, tC = 0;
    for (const r of tableRows) { dT += r.deviceTotal; dC += r.deviceCompleted; tT += r.toolTotal; tC += r.toolCompleted; }
    return {
      deviceTotal: dT, deviceCompleted: dC,
      deviceRate: dT > 0 ? Math.round(dC / dT * 1000) / 10 : 0,
      toolTotal: tT, toolCompleted: tC,
      toolRate: tT > 0 ? Math.round(tC / tT * 1000) / 10 : 0,
    };
  }, [tableRows]);

  const rateColor = (rate: number) => rate < 60 ? '#ff4d4f' : '#52c41a';

  return (
    <div style={{ overflowX: 'hidden', maxWidth: '100%' }}>
      {/* 筛选器 */}
      <div style={{ marginBottom: 16, display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <select value={yearFilter} onChange={e => setYearFilter(e.target.value)}
          style={{ padding: '3px 8px', borderRadius: 4, border: '1px solid var(--border)', background: 'var(--card-bg, #1a1a2e)', color: 'var(--text, #e0e0e0)', fontSize: 13 }}>
          {YEAR_OPTIONS.map(y => <option key={y} value={y}>{y === '全部' ? '全部年份' : y + '年'}</option>)}
        </select>
        <select value={lineFilter} onChange={e => setLineFilter(e.target.value)}
          style={{ padding: '3px 8px', borderRadius: 4, border: '1px solid var(--border)', background: 'var(--card-bg, #1a1a2e)', color: 'var(--text, #e0e0e0)', fontSize: 13 }}>
          {LINE_OPTIONS.map(l => <option key={l} value={l}>{l === '全部' ? '全部线体' : l}</option>)}
        </select>
      </div>

      {/* 统计卡片 - 响应式两行四列布局 */}
      <style>{`
        @media (max-width: 768px) {
          .stats-card-grid { grid-template-columns: repeat(2, 1fr) !important; }
          .stats-card { height: 100px !important; padding: 10px !important; }
          .stats-card .stat-title { font-size: 11px !important; margin-bottom: 4px !important; }
          .stats-card .stat-value { font-size: 24px !important; }
          .stats-card .stat-sub { font-size: 10px !important; }
        }
        @media (max-width: 400px) {
          .stats-card-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 10px !important; }
        }
      `}</style>
      <div className="stats-card-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        {/* 第一行 */}
        <div className="card stats-card" style={{ height: 110, borderRadius: 12, padding: 14, textAlign: 'center', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-4px)', e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.3)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'none', e.currentTarget.style.boxShadow = 'none')}>
          <div className="stat-title" style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>设备维修总工单</div>
          <div className="stat-value" style={{ fontSize: 32, fontWeight: 'bold', color: '#e0e0e0' }}>{deviceSummary.total}</div>
          <div className="stat-sub" style={{ fontSize: 12, color: '#888', marginTop: 4 }}>
            完成 <span style={{ color: '#52c41a' }}>{deviceSummary.completed}</span> 件
          </div>
        </div>
        <div className="card stats-card" style={{ height: 110, borderRadius: 12, padding: 14, textAlign: 'center', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-4px)', e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.3)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'none', e.currentTarget.style.boxShadow = 'none')}>
          <div className="stat-title" style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>设备维修完成率</div>
          <div className="stat-value" style={{ fontSize: 32, fontWeight: 'bold', color: rateColor(deviceSummary.completionRate) }}>{deviceSummary.completionRate}%</div>
        </div>
        <div className="card stats-card" style={{ height: 110, borderRadius: 12, padding: 14, textAlign: 'center', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-4px)', e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.3)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'none', e.currentTarget.style.boxShadow = 'none')}>
          <div className="stat-title" style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>工具维修总工单</div>
          <div className="stat-value" style={{ fontSize: 32, fontWeight: 'bold', color: '#e0e0e0' }}>{toolSummary.total}</div>
          <div className="stat-sub" style={{ fontSize: 12, color: '#888', marginTop: 4 }}>
            完成 <span style={{ color: '#52c41a' }}>{toolSummary.completed}</span> 件
          </div>
        </div>
        <div className="card stats-card" style={{ height: 110, borderRadius: 12, padding: 14, textAlign: 'center', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-4px)', e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.3)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'none', e.currentTarget.style.boxShadow = 'none')}>
          <div className="stat-title" style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>工具维修完成率</div>
          <div className="stat-value" style={{ fontSize: 32, fontWeight: 'bold', color: rateColor(toolSummary.completionRate) }}>{toolSummary.completionRate}%</div>
        </div>
        {/* 第二行 */}
        <div className="card stats-card" style={{ height: 110, borderRadius: 12, padding: 14, textAlign: 'center', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-4px)', e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.3)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'none', e.currentTarget.style.boxShadow = 'none')}>
          <div className="stat-title" style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>设备总数</div>
          <div className="stat-value" style={{ fontSize: 32, fontWeight: 'bold', color: '#e0e0e0' }}>{overview?.deviceCount ?? '-'}</div>
        </div>
        <div className="card stats-card" style={{ height: 110, borderRadius: 12, padding: 14, textAlign: 'center', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-4px)', e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.3)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'none', e.currentTarget.style.boxShadow = 'none')}>
          <div className="stat-title" style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>待处理工单</div>
          <div className="stat-value" style={{ fontSize: 32, fontWeight: 'bold', color: 'orange' }}>{overview?.repairCount ?? '-'}</div>
        </div>
        <div className="card stats-card" style={{ height: 110, borderRadius: 12, padding: 14, textAlign: 'center', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-4px)', e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.3)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'none', e.currentTarget.style.boxShadow = 'none')}>
          <div className="stat-title" style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>物品种类</div>
          <div className="stat-value" style={{ fontSize: 32, fontWeight: 'bold', color: '#e0e0e0' }}>{overview?.partCount ?? '-'}</div>
        </div>
        <div className="card stats-card" style={{ height: 110, borderRadius: 12, padding: 14, textAlign: 'center', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-4px)', e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.3)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'none', e.currentTarget.style.boxShadow = 'none')}>
          <div className="stat-title" style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>低库存预警</div>
          <div className="stat-value" style={{ fontSize: 32, fontWeight: 'bold', color: 'red' }}>{overview?.lowStockCount ?? '-'}</div>
        </div>
      </div>

      {/* 月度趋势图 */}
      {trendByMonth.length > 0 && (
        <div className="card" style={{ padding: 16, marginBottom: 16, overflowX: 'hidden' }}>
          <h3 style={{ marginTop: 0, marginBottom: 12, fontSize: 15 }}>设备维修 vs 工具维修 月度趋势</h3>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height: 180, borderBottom: '1px solid var(--border)', borderLeft: '1px solid var(--border)', paddingLeft: 36, position: 'relative' }}>
            {/* Y轴刻度 */}
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 32, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', fontSize: 11, color: '#888' }}>
              <span>{trendMax}</span>
              <span>{Math.round(trendMax / 2)}</span>
              <span>0</span>
            </div>
            {trendByMonth.map(([month, data], i) => {
              const dv = data.device?.total || 0;
              const tv = data.tool?.total || 0;
              return (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', justifyContent: 'flex-end', minWidth: 0 }}>
                  <div style={{ width: '100%', display: 'flex', gap: 1, justifyContent: 'center', alignItems: 'flex-end', height: '100%' }}>
                    {/* 设备维修柱 */}
                    <div title={`设备维修: ${dv}单`} style={{ width: 12, minHeight: dv > 0 ? 3 : 0, height: `${(dv / trendMax) * 100}%`, backgroundColor: 'var(--accent-cyan, #00d4ff)', borderRadius: '2px 2px 0 0', transition: 'height 0.3s' }}>
                      {dv > 0 && <div style={{ fontSize: 10, color: '#fff', textAlign: 'center', lineHeight: '12px' }}>{dv}</div>}
                    </div>
                    {/* 工具维修柱 */}
                    <div title={`工具维修: ${tv}单`} style={{ width: 12, minHeight: tv > 0 ? 3 : 0, height: `${(tv / trendMax) * 100}%`, backgroundColor: '#faad14', borderRadius: '2px 2px 0 0', transition: 'height 0.3s' }}>
                      {tv > 0 && <div style={{ fontSize: 10, color: '#fff', textAlign: 'center', lineHeight: '12px' }}>{tv}</div>}
                    </div>
                  </div>
                  <div style={{ fontSize: 10, color: '#888', marginTop: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '100%' }}>{month}</div>
                </div>
              );
            })}
          </div>
          <div style={{ display: 'flex', gap: 16, marginTop: 8, fontSize: 12, color: '#aaa' }}>
            <span><span style={{ display: 'inline-block', width: 12, height: 12, backgroundColor: 'var(--accent-cyan, #00d4ff)', borderRadius: 2, marginRight: 4, verticalAlign: 'middle' }} />设备维修</span>
            <span><span style={{ display: 'inline-block', width: 12, height: 12, backgroundColor: '#faad14', borderRadius: 2, marginRight: 4, verticalAlign: 'middle' }} />工具维修</span>
          </div>
        </div>
      )}

      {/* 维修数据统计表格 */}
      <div className="card" style={{ marginBottom: 16, padding: 12, overflowX: 'hidden' }}>
        <h3 style={{ marginTop: 0, marginBottom: 12, fontSize: 15 }}>维修数据统计</h3>
        <div style={{ overflowX: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, tableLayout: 'fixed' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid var(--border)' }}>
                <th style={{ padding: '8px 6px', textAlign: 'left', whiteSpace: 'nowrap' }}>线体</th>
                <th style={{ padding: '8px 4px', textAlign: 'center' }}>设备故障次数</th>
                <th style={{ padding: '8px 4px', textAlign: 'center' }}>设备维修完结率</th>
                <th style={{ padding: '8px 4px', textAlign: 'center' }}>工具维修次数</th>
                <th style={{ padding: '8px 4px', textAlign: 'center' }}>工具维修完结率</th>
              </tr>
            </thead>
            <tbody>
              {tableRows.length === 0 && (
                <tr><td colSpan={5} style={{ padding: 16, textAlign: 'center', color: '#888' }}>暂无数据</td></tr>
              )}
              {tableRows.map((r, i) => (
                <tr key={i} style={{ borderBottom: '1px solid var(--border, rgba(255,255,255,0.06))' }}>
                  <td style={{ padding: '8px 6px', fontWeight: 500, whiteSpace: 'nowrap' }}>{r.line}</td>
                  <td style={{ padding: '8px 4px', textAlign: 'center' }}>{r.deviceTotal}</td>
                  <td style={{ padding: '8px 4px', textAlign: 'center', color: rateColor(r.deviceRate), fontWeight: r.deviceRate < 60 ? 700 : 400 }}>{r.deviceRate}%</td>
                  <td style={{ padding: '8px 4px', textAlign: 'center' }}>{r.toolTotal}</td>
                  <td style={{ padding: '8px 4px', textAlign: 'center', color: rateColor(r.toolRate), fontWeight: r.toolRate < 60 ? 700 : 400 }}>{r.toolRate}%</td>
                </tr>
              ))}
            </tbody>
            {tableRows.length > 0 && (
              <tfoot>
                <tr style={{ borderTop: '2px solid var(--accent-cyan, #00d4ff)', fontWeight: 700 }}>
                  <td style={{ padding: '10px 6px', fontWeight: 700 }}>合计</td>
                  <td style={{ padding: '10px 4px', textAlign: 'center' }}>{totals.deviceTotal}</td>
                  <td style={{ padding: '10px 4px', textAlign: 'center', color: rateColor(totals.deviceRate) }}>{totals.deviceRate}%</td>
                  <td style={{ padding: '10px 4px', textAlign: 'center' }}>{totals.toolTotal}</td>
                  <td style={{ padding: '10px 4px', textAlign: 'center', color: rateColor(totals.toolRate) }}>{totals.toolRate}%</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* 停线时长按月统计 */}
      {stopDurationData.length > 0 && (
        <div className="card" style={{ padding: 16, marginBottom: 16, overflowX: 'hidden' }}>
          <h3 style={{ marginTop: 0, marginBottom: 12, fontSize: 15 }}>停线时长按月统计</h3>
          {(() => {
            const maxMinutes = Math.max(...stopDurationData.map(d => d.totalMinutes), 1);
            return (
              <>
                <div style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height: 160, borderBottom: '1px solid var(--border)', borderLeft: '1px solid var(--border)', paddingLeft: 36, position: 'relative', marginBottom: 8 }}>
                  <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 32, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', fontSize: 11, color: '#888' }}>
                    <span>{maxMinutes}</span>
                    <span>{Math.round(maxMinutes / 2)}</span>
                    <span>0</span>
                  </div>
                  {stopDurationData.map((d, i) => (
                    <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', justifyContent: 'flex-end', minWidth: 0 }}>
                      <div title={`总停线: ${d.totalMinutes}分钟`}
                        style={{ width: '80%', minHeight: d.totalMinutes > 0 ? 3 : 0, height: `${(d.totalMinutes / maxMinutes) * 100}%`, backgroundColor: '#ff6b6b', borderRadius: '2px 2px 0 0', transition: 'height 0.3s' }}>
                        {d.totalMinutes > 0 && <div style={{ fontSize: 10, color: '#fff', textAlign: 'center', lineHeight: '12px' }}>{d.totalMinutes}</div>}
                      </div>
                      <div style={{ fontSize: 10, color: '#888', marginTop: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.month}</div>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, fontSize: 11, color: '#888', flexWrap: 'wrap', gap: 8 }}>
                  <span>总停线: <strong style={{ color: '#ff6b6b' }}>{stopDurationData.reduce((sum, d) => sum + d.totalMinutes, 0)}</strong> 分钟</span>
                  <span>月均: <strong>{Math.round(stopDurationData.reduce((sum, d) => sum + d.totalMinutes, 0) / stopDurationData.length)}</strong> 分钟</span>
                </div>
              </>
            );
          })()}
        </div>
      )}

      {/* 线体故障率折线图 */}
      {faultRateData.length > 0 && (
        <div className="card" style={{ padding: 16, marginBottom: 16, overflowX: 'hidden' }}>
          <h3 style={{ marginTop: 0, marginBottom: 12, fontSize: 15 }}>线体故障率趋势</h3>
          {(() => {
            const lineColors: Record<string, string> = {
              '1线': '#00d4ff', '2线': '#faad14', '3线': '#52c41a', '4线': '#ff4d4f',
              'VIP线': '#722ed1', '紫外': '#eb2f96', '紫外车间': '#fa8c16', '工艺': '#13c2c2', '工艺组': '#2f54eb'
            };
            const months = [...new Set(faultRateData.map(d => d.month))].sort();
            const lines = [...new Set(faultRateData.map(d => d.line))].slice(0, 5);
            const maxFault = Math.max(...faultRateData.map(d => d.faultCount), 1);
            
            return (
              <>
                <div style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height: 180, borderBottom: '1px solid var(--border)', borderLeft: '1px solid var(--border)', paddingLeft: 36, position: 'relative' }}>
                  <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 32, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', fontSize: 11, color: '#888' }}>
                    <span>{maxFault}</span>
                    <span>{Math.round(maxFault / 2)}</span>
                    <span>0</span>
                  </div>
                  {months.map((month, mi) => (
                    <div key={mi} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', justifyContent: 'flex-end', minWidth: 0 }}>
                      <div style={{ display: 'flex', gap: 1, alignItems: 'flex-end', height: 'calc(100% - 20px)', width: '100%', justifyContent: 'center' }}>
                        {lines.map((line, li) => {
                          const item = faultRateData.find(d => d.month === month && d.line === line);
                          const count = item?.faultCount || 0;
                          const height = count > 0 ? (count / maxFault) * 100 : 0;
                          return (
                            <div key={li} title={`${line}: ${count}次`}
                              style={{ width: 6, minHeight: count > 0 ? 2 : 0, height: `${height}%`, backgroundColor: lineColors[line] || '#888', borderRadius: '2px 2px 0 0', transition: 'height 0.3s' }} />
                          );
                        })}
                      </div>
                      <div style={{ fontSize: 10, color: '#888', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{month}</div>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', gap: 12, marginTop: 10, fontSize: 11, color: '#aaa', flexWrap: 'wrap' }}>
                  {lines.map(line => (
                    <span key={line} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <span style={{ display: 'inline-block', width: 10, height: 10, backgroundColor: lineColors[line] || '#888', borderRadius: 2 }} />
                      {line}
                    </span>
                  ))}
                </div>
              </>
            );
          })()}
        </div>
      )}

      {/* 故障频率 TOP20 */}
      <div className="card" style={{ marginBottom: 16, padding: 12, overflowX: 'hidden' }}>
        <h3 style={{ margin: '0 0 12px 0', fontSize: 15 }}>故障频率 TOP20（近90天）</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, tableLayout: 'fixed' }}>
          <thead><tr><th style={{ padding: '8px 6px', textAlign: 'left' }}>编号</th><th style={{ padding: '8px 6px', textAlign: 'left' }}>名称</th><th style={{ padding: '8px 6px', textAlign: 'center' }}>次数</th><th style={{ padding: '8px 6px', textAlign: 'center' }}>均耗时</th></tr></thead>
          <tbody>
            {faultFreq.map((d: any, i: number) => <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '8px 6px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.deviceNo}</td>
              <td style={{ padding: '8px 6px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.deviceName}</td>
              <td style={{ padding: '8px 6px', textAlign: 'center' }}>{d.faultCount}</td>
              <td style={{ padding: '8px 6px', textAlign: 'center' }}>{d.avgDuration ?? '-'}</td>
            </tr>)}
          </tbody>
        </table>
      </div>


      {/* 低库存预警 */}
      {lowStock.length > 0 && (
        <div className="card" style={{ border: '2px solid red', marginBottom: 16, padding: 12, overflowX: 'hidden' }}>
          <h3 style={{ color: 'red', margin: '0 0 12px 0', fontSize: 15 }}>低库存预警</h3>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, tableLayout: 'fixed' }}>
            <thead><tr><th style={{ padding: '8px 6px', textAlign: 'left' }}>编号</th><th style={{ padding: '8px 6px', textAlign: 'left' }}>名称</th><th style={{ padding: '8px 6px', textAlign: 'center' }}>库存</th><th style={{ padding: '8px 6px', textAlign: 'center' }}>安全</th></tr></thead>
            <tbody>
              {lowStock.map((d: any) => <tr key={d.id} style={{ borderBottom: '1px solid var(--border)' }}>
                <td style={{ padding: '8px 6px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.part_no}</td>
                <td style={{ padding: '8px 6px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.name}</td>
                <td style={{ padding: '8px 6px', textAlign: 'center', color: 'red', fontWeight: 700 }}>{d.stock}</td>
                <td style={{ padding: '8px 6px', textAlign: 'center' }}>{d.safety_stock}</td>
              </tr>)}
            </tbody>
          </table>
        </div>
      )}

    </div>
  );
}
