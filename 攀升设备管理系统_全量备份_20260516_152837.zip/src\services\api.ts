import axios from 'axios';
const api = axios.create({
  baseURL: '/api',
  withCredentials: true,
  timeout: 60000, // 60秒超时，大文件导入需要更长处理时间
});

// ===== 设备 =====
export const deviceApi = {
  list: () => api.get('/devices'),
  get: (id: string) => api.get(`/devices/${id}`),
  create: (d: any) => api.post('/devices', d),
  update: (id: string, d: any) => api.put(`/devices/${id}`, d),
  delete: (id: string) => api.delete(`/devices/${id}`),
  scrap: (id: string, d: any) => api.put(`/devices/${id}/scrap`, d),
  restore: (id: string) => api.put(`/devices/${id}/restore`),
  changeRecords: (params?: any) => api.get('/devices/change-records', { params }),
  importExcel: (file: File) => {
    const fd = new FormData(); fd.append('file', file);
    return api.post('/devices/import', fd);
  },
  categories: () => api.get('/devices/categories/list'),
};

// ===== 维修工单 =====
export const repairApi = {
  list: (params?: any) => api.get('/repairs', { params }),
  create: (d: any) => api.post('/repairs', d),
  update: (id: string, d: any) => api.put(`/repairs/${id}`, d),
  delete: (id: string) => api.delete(`/repairs/${id}`),
  start: (id: string) => api.post(`/repairs/${id}/start`),
  complete: (id: string, d: any) => api.post(`/repairs/${id}/complete`, d),
  statsOverview: (params?: any) => api.get('/repairs/stats/overview', { params }),
  statsHighFreq: () => api.get('/repairs/stats/high-frequency'),
  statsMonthlyTrend: (params?: any) => api.get('/repairs/stats/monthly-trend', { params }),
  statsByLine: (params?: any) => api.get('/repairs/stats/by-line', { params }),
  statsSummary: (params?: any) => api.get('/repairs/stats/summary', { params }),
  nextNo: () => api.get('/repairs/next-no'),
};

// ===== 零部件 =====
export const partApi = {
  list: (keyword?: string) => api.get('/parts', { params: keyword ? { keyword } : {} }),
  create: (d: any) => api.post('/parts', d),
  update: (id: string, d: any) => api.put(`/parts/${id}`, d),
  patchStock: (id: string, stock: number) => api.patch(`/parts/${id}/stock`, { stock }),
  delete: (id: string) => api.delete(`/parts/${id}`),
  importExcel: (file: File) => {
    const fd = new FormData(); fd.append('file', file);
    return api.post('/parts/import', fd);
  },
  lowStock: () => api.get('/parts/low-stock'),
  logs: () => api.get('/parts/logs'),
  createLog: (d: any) => api.post('/parts/logs', d),
  nextNo: () => api.get('/parts/next-no'),
  // 领用
  usage: (d: any) => api.post('/parts/usage', d),
  usageLogs: (params?: any) => api.get('/parts/usage', { params }),
  // 管理员：待审批列表
  usagePending: () => api.get('/parts/usage/pending'),
  // 管理员：审批通过
  usageApprove: (id: string) => api.post(`/parts/usage/${id}/approve`),
  // 管理员：驳回申请
  usageReject: (id: string, reason: string) => api.post(`/parts/usage/${id}/reject`, { reason }),
  // 管理员：修改领用申请
  usageUpdate: (id: string, data: { part_id?: number; quantity?: number }) => api.put(`/parts/usage/${id}`, data),
  // 入库
  stockin: (d: any) => api.post('/parts/stockin', d),
  stockinLogs: (params?: any) => api.get('/parts/stockin', { params }),
};

// ===== 保养计划 =====
export const maintenanceApi = {
  list: () => api.get('/maintenance'),
  create: (d: any) => api.post('/maintenance', d),
  update: (id: string, d: any) => api.put(`/maintenance/${id}`, d),
  delete: (id: string) => api.delete(`/maintenance/${id}`),
  nextNo: () => api.get('/maintenance/next-no'),
};

// ===== 工具台账 =====
export const toolApi = {
  list: () => api.get('/tools'),
  get: (id: string) => api.get(`/tools/${id}`),
  create: (d: any) => api.post('/tools', d),
  update: (id: string, d: any) => api.put(`/tools/${id}`, d),
  delete: (id: string) => api.delete(`/tools/${id}`),
  scrap: (id: string, d: any) => api.put(`/tools/${id}/scrap`, d),
  changeRecords: (params?: any) => api.get('/tools/change-records', { params }),
  importExcel: (file: File) => {
    const fd = new FormData(); fd.append('file', file);
    return api.post('/tools/import', fd);
  },
};

// ===== 统计 =====
export const statsApi = {
  overview: () => api.get('/stats/overview'),
  faultFrequency: () => api.get('/stats/fault-frequency'),
  faultTypes: () => api.get('/stats/fault-types'),
  lowStock: () => api.get('/stats/low-stock'),
  stopDurationByMonth: (params?: any) => api.get('/stats/stop-duration-by-month', { params }),
  faultRateByMonth: (params?: any) => api.get('/stats/fault-rate-by-month', { params }),
};

// ===== 数据版本检查（智能刷新）=====
export const dataVersionApi = {
  check: () => api.get('/data-version'),
};

// ===== 通知设置 =====
export const notificationApi = {
  getConfig: () => api.get('/notifications/config'),
  updateConfig: (d: any) => api.put('/notifications/config', d),
  testSend: () => api.post('/notifications/test'),
  sendPending: () => api.post('/notifications/send-pending'),
  logs: (limit?: number) => api.get('/notifications/logs', { params: { limit } }),
};
